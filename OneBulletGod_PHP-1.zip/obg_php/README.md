# ONE BULLET GOD — PHP Secure Version

## Folder Structure
```
obg_php/
├── index.php          ← Main entry (PHP security headers, session, CSP)
├── .htaccess          ← Apache rules (block /data/, gzip, caching)
├── api/
│   └── score.php      ← Score submit + leaderboard API
├── assets/
│   ├── game.css       ← All styles
│   ├── game.js        ← All game logic + PHP API integration
│   └── screens.html   ← All HTML screen templates (included by PHP)
└── data/              ← AUTO-CREATED by PHP (keep outside webroot ideally)
    ├── scores.json    ← Leaderboard data
    ├── rate_limit.json← Rate limiting tracker
    ├── suspicious.log ← Anti-cheat log
    └── saves/         ← Per-session save backups
        └── {sid}.json
```

## Deployment Steps

### 1. Upload Files
Upload entire `obg_php/` folder to your hosting via FTP or cPanel File Manager.

### 2. Set Permissions
```bash
chmod 755 obg_php/
chmod 644 obg_php/*.php obg_php/.htaccess
chmod 755 obg_php/api/ obg_php/assets/
chmod 777 obg_php/data/   ← PHP needs write access here
```

### 3. Test
Visit `https://yourdomain.com/obg_php/` — game should load.

### 4. Add Remaining Adsterra Ads
In `index.php`, find the comments and paste your ad codes:
- Bottom rectangle (300×250) — highest revenue
- Interstitial (300×250) — between levels
- Social bar — in `<head>`

## Security Features

| Feature | How |
|---|---|
| CSRF Protection | PHP generates token → JS sends in header → API validates |
| Rate Limiting | Max 20 score submissions/minute per IP |
| Anti-Cheat | Server validates coins/kills ratio, time played, impossible values |
| XSS Protection | CSP headers + htmlspecialchars on all output |
| Data Protection | `/data/` folder blocked via .htaccess, IPs hashed |
| No Direct JS Edit | Game config injected by PHP, not editable by user |

## Adsterra Revenue Tips
- 300×250 Rectangle = highest RPM (keep it)
- Social Bar = passive income (floating bar)
- Between-level interstitial = good for engaged users
- Never click your own ads (account ban)
