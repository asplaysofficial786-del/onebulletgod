// ── CANVAS ────────────────────────────────────────────
const C=document.getElementById('c'),ctx=C.getContext('2d');
const BW=480,BH=720;C.width=BW;C.height=BH;
let SX=1;
function resize(){
  const r=BW/BH,ww=innerWidth;
  // Account for top banner ad only
  const adH=document.querySelector('.ad-top')?.offsetHeight||90;
  const wh=Math.max(200, innerHeight-adH);
  let cw,ch;
  ww/wh>r?(ch=wh,cw=wh*r):(cw=ww,ch=ww/r);
  if(cw>ww){cw=ww;ch=ww/r;}
  C.style.width=cw+'px';C.style.height=ch+'px';SX=cw/BW;
}
resize();addEventListener('resize',resize);

// ── CONSTANTS ─────────────────────────────────────────
const ROOM={x:20,y:112,w:440,h:568};
const BASE_BR=7, EN_R=15, GUN_R=11, PUP_R=14, PORT_R=17;
const STEP=2.2, MAX_STEPS=22000;
const XP_PER_KILL=14, BASE_CPK=20, PERF_BONUS=80, DAILY_BONUS=200;
const MAX_PLV=10, XP_PER_LV=100;

// ── GAME STATE ────────────────────────────────────────
let gs='menu';
let lvIdx=0,coins=0,xp=0,plvl=1,sp=0;
let skills={};
let upg={bounceUp:0,caliber:0,coinBoost:0,idleMine:0,extraLives:0};
let prestige=0;
let streak=0,lastPlayDate='',dailyDone=false,dailyDate='';
let totalKills=0,totalShots=0;
let lives=3,hints=1,skips=0,shopBuys=0;
let lvStarsMap={},achDone={},failsOnLevel=0;
let lastSaveMs=0;

// Level runtime
let lvEn=[],lvWalls=[],lvMW=[],lvPortals=[],lvPups=[],lvGun={x:240,y:640};
let lvBL=20,lvDark=false;
let aimAngle=null,traj=[],trajHits=[];
let parts=[],floats=[];
let shake=0,flashA=0,flashCol='255,215,0';
let combo=0,comboT=0;
let killsLv=0,coinsLv=0,xpLv=0,shotsLv=0,lvStars=0;
let slowMo=false,slowMoT=0;
let magnet=false,magnetT=0;
let activePup=null;
let fBuls=[],fDone=false;
let lastTs=0,lastBounceT=0;
let bounceFrozen=false; // TIME FREEZE stops bounce counting

// ── AUDIO ─────────────────────────────────────────────
let ac=null;
function getAC(){if(!ac)ac=new(AudioContext||webkitAudioContext)();return ac;}
function tone(f,d,tp='sine',vol=.2,f2=null){
  try{const a=getAC(),o=a.createOscillator(),g=a.createGain();
  o.connect(g);g.connect(a.destination);o.type=tp;
  o.frequency.setValueAtTime(f2||f,a.currentTime);
  if(f2)o.frequency.linearRampToValueAtTime(f,a.currentTime+d*.4);
  g.gain.setValueAtTime(vol,a.currentTime);
  g.gain.exponentialRampToValueAtTime(.001,a.currentTime+d);
  o.start();o.stop(a.currentTime+d);}catch(e){}
}
const SND={
  fire:()=>tone(850,.07,'square',.18,180),
  bounce:()=>tone(400+Math.random()*260,.06,'square',.1),
  kill:()=>{tone(250,.16,'sawtooth',.2);setTimeout(()=>tone(500,.1,'sine',.15),30);},
  win:()=>[523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone(f,.25,'sine',.2),i*72)),
  lose:()=>[350,260,170].forEach((f,i)=>setTimeout(()=>tone(f,.2,'sawtooth',.15),i*95)),
  upgrade:()=>[380,500,660,880].forEach((f,i)=>setTimeout(()=>tone(f,.09,'sine',.23),i*48)),
  combo:n=>tone(640+n*80,.08,'square',.15),
  pup:()=>[560,720,920].forEach((f,i)=>setTimeout(()=>tone(f,.09,'sine',.2),i*38)),
  portal:()=>tone(280,.14,'sine',.17,760),
  boss:()=>tone(75,.38,'sawtooth',.28,55),
  lvlup:()=>[380,480,600,760,960].forEach((f,i)=>setTimeout(()=>tone(f,.18,'sine',.26),i*55)),
  freeze:()=>[800,600,400].forEach((f,i)=>setTimeout(()=>tone(f,.12,'sine',.2),i*60)),
};

// ── SAVE / LOAD ───────────────────────────────────────
function save(){
  lastSaveMs=Date.now();
  try{localStorage.setItem('obg6',JSON.stringify({
    coins,xp,plvl,sp,skills,upg,prestige,streak,lastPlayDate,dailyDone,dailyDate,
    totalKills,totalShots,lvIdx,lives,hints,skips,shopBuys,lvStarsMap,achDone,lastSaveMs
  }));}catch(e){}
  flashSaveBadge();
}
function load(){
  try{const d=JSON.parse(localStorage.getItem('obg6')||localStorage.getItem('obg5')||'{}');
  coins=d.coins||0;xp=d.xp||0;plvl=d.plvl||1;sp=d.sp||0;
  skills=d.skills||{};
  const du=d.upg||{};
  upg={bounceUp:du.bounceUp||0,caliber:du.caliber||0,coinBoost:du.coinBoost||0,idleMine:du.idleMine||0,extraLives:du.extraLives||0};
  prestige=d.prestige||0;streak=d.streak||0;lastPlayDate=d.lastPlayDate||'';
  dailyDone=d.dailyDone||false;dailyDate=d.dailyDate||'';
  totalKills=d.totalKills||0;totalShots=d.totalShots||0;
  lives=d.lives!==undefined?d.lives:3+upg.extraLives*2;
  hints=d.hints!==undefined?d.hints:1;skips=d.skips||0;shopBuys=d.shopBuys||0;
  lvStarsMap=d.lvStarsMap||{};achDone=d.achDone||{};
  lvIdx=Math.max(0,Math.min(d.lvIdx||0,LEVELS?LEVELS.length-1:29));
  // Grant idle coins
  if(d.lastSaveMs&&upg.idleMine>0){
    const hrs=(Date.now()-d.lastSaveMs)/3600000;
    const idleEarned=Math.floor(hrs*upg.idleMine*8);
    if(idleEarned>0){coins+=idleEarned;setTimeout(()=>fl(BW/2,320,`+${idleEarned} OFFLINE COINS ⛏️`,'#ffd700',14),600);}
  }}catch(e){}
  checkStreak();
}
function flashSaveBadge(){
  let b=document.getElementById('saveBadge');
  if(!b){b=document.createElement('div');b.id='saveBadge';
    b.style.cssText='position:fixed;bottom:10px;right:12px;background:rgba(61,255,160,.12);border:1px solid rgba(61,255,160,.35);color:#3dffa0;font-family:Orbitron,monospace;font-size:7.5px;letter-spacing:2px;padding:5px 10px;z-index:999;transition:opacity .4s;pointer-events:none;';
    b.textContent='✓ SAVED';document.body.appendChild(b);}
  b.style.opacity='1';clearTimeout(b._t);b._t=setTimeout(()=>b.style.opacity='0',1800);
}
function checkStreak(){
  const today=new Date().toDateString();
  if(!lastPlayDate){lastPlayDate=today;save();return;}
  const diff=Math.floor((new Date()-new Date(lastPlayDate))/(864e5));
  if(diff===1)streak++;else if(diff>1)streak=1;
  lastPlayDate=today;save();
}

// ── PARTICLES ─────────────────────────────────────────
function pt(x,y,vx,vy,c,life,sz=2.5,g=.1){parts.push({x,y,vx,vy,c,life,ml:life,sz,g});}
function burst(x,y,c='#ff5500',n=18,pw=5.5){
  for(let i=0;i<n;i++){const a=i/n*Math.PI*2+Math.random()*.5,sp2=pw*(.5+Math.random()*.9);
  pt(x,y,Math.cos(a)*sp2,Math.sin(a)*sp2,c,.5+Math.random()*.5,2+Math.random()*3,.14);}
  for(let i=0;i<5;i++){const a=Math.random()*Math.PI*2;
  pt(x,y,Math.cos(a)*(pw+3),Math.sin(a)*(pw+3),'#fff8bb',.25,1.5,.2);}
}
function fl(x,y,txt,c='#ffd700',sz=13){floats.push({x,y,txt,c,sz,life:1.3,ml:1.3,vy:-1.3});}
function updParts(dt){
  const sd=slowMo?.22:1;
  for(let i=parts.length-1;i>=0;i--){
    const p=parts[i];p.x+=p.vx*sd;p.y+=p.vy*sd;p.vy+=p.g*sd;p.vx*=.96;p.life-=dt;
    if(p.life<=0)parts.splice(i,1);
  }
  for(let i=floats.length-1;i>=0;i--){
    const f=floats[i];f.y+=f.vy;f.life-=dt;if(f.life<=0)floats.splice(i,1);
  }
}

// ── HELPERS ───────────────────────────────────────────
const hs=id=>!!skills[id];
function getBR(){return BASE_BR+(hs('caliber')?4:0)+(upg.caliber*2);}
function getMaxLives(){return 3+(upg.extraLives||0)*2;}
function getMaxB(bl){
  let b=bl+(upg.bounceUp*8);
  if(hs('bounces1'))b+=12;
  if(hs('bounces2'))b+=20;
  return Math.min(b,50);
}
function getCPK(){
  let base=BASE_CPK*(1+(upg.coinBoost*.5));
  if(hs('coinBoost'))base*=1.5;
  if(hs('coinBoost2'))base*=1.6;
  return Math.round(base*[1,1.5,2,3][Math.min(prestige,3)]);
}
function getXPK(){return Math.round(XP_PER_KILL*(hs('xpBoost')?1.5:1));}
function getBT(){if(hs('homing'))return'homing';if(hs('gravBullet'))return'gravity';return'normal';}
function getSC(){if(hs('starBurst')||activePup==='starburst')return 8;if(hs('tripleShot'))return 3;return 1;}
function getFreezeDur(){return hs('freezeExt')?9:6;}
function getMagR(){return hs('magnetStr')?160:95;}

// ── SHOP DEFS ─────────────────────────────────────────
const SHOP=[
  // ── PERMANENT UPGRADES ──
  {id:'bounceUp',nm:'RICOCHET+',ic:'↩️',type:'perm',
   ds:'+8 bounces/level. Stack up to 50 total bounces.',
   max:5,costs:[30,70,150,300,500],val:l=>`+${l*8} bounces (cap 50)`},
  {id:'caliber',nm:'BIG BORE',ic:'🎯',type:'perm',
   ds:'Larger bullet radius. Hits enemies easier.',
   max:4,costs:[45,110,250,500],val:l=>`+${l*2}px radius`},
  {id:'coinBoost',nm:'BOUNTY',ic:'💰',type:'perm',
   ds:'+50% coins per kill per level.',
   max:4,costs:[55,130,270,500],val:l=>`×${(1+l*.5).toFixed(1)} coin mult`},
  {id:'idleMine',nm:'COIN MINE',ic:'⛏️',type:'perm',
   ds:'+8 coins/hr while offline. Earned on next login.',
   max:5,costs:[80,160,300,550,900],val:l=>`${l*8}/hr idle`},
  {id:'extraLives',nm:'EXTRA LIVES',ic:'💼',type:'perm',
   ds:'+2 max lives per level. Lives refill on win.',
   max:3,costs:[120,300,600],val:l=>`${3+l*2} max lives`},
  // ── CONSUMABLES (cost coins, grant immediate item) ──
  {id:'buyLives',nm:'REFILL LIVES',ic:'❤️',type:'cons',
   ds:'Fully refill your lives right now.',
   cost:()=>40,val:()=>`${lives}/${getMaxLives()} lives`},
  {id:'buyHint',nm:'BUY HINT',ic:'💡',type:'cons',
   ds:'Shows best aim angle for 1 shot. Use on lose screen.',
   cost:()=>35,val:()=>`${hints} hint(s) owned`},
  {id:'buySkip',nm:'LEVEL SKIP',ic:'⏭️',type:'cons',
   ds:'Skip the current level when stuck.',
   cost:()=>120,val:()=>`${skips} skip(s) owned`},
  {id:'buyFreeze',nm:'FREEZE TOKEN',ic:'❄️',type:'cons',
   ds:'Activates time freeze on your next shot.',
   cost:()=>55,val:()=>`Use before firing`},
  {id:'buyBomb',nm:'BOMB TOKEN',ic:'💣',type:'cons',
   ds:'Next bullet hit creates a chain explosion.',
   cost:()=>55,val:()=>`Use before firing`},
  {id:'buyStarburst',nm:'STARBURST',ic:'⭐',type:'cons',
   ds:'Fire 8 bullets on your next shot.',
   cost:()=>65,val:()=>`Use before firing`},
];

// ── SKILL DEFS ────────────────────────────────────────
const SKILLS=[
  {id:'armorPierce',nm:'ARMOR PIERCE',br:'OFFENSE',ic:'⚔️',sp:1,req:null,
   ds:'One-shots armored enemies (normally 2 hits).'},
  {id:'explosive',nm:'EXPLOSIVE',br:'OFFENSE',ic:'💥',sp:2,req:'armorPierce',
   ds:'Kills detonate enemies within 80px radius.'},
  {id:'splitShot',nm:'SPLIT SHOT',br:'OFFENSE',ic:'🔀',sp:2,req:'explosive',
   ds:'On first wall bounce bullet splits into 2.'},
  {id:'starBurst',nm:'STAR BURST',br:'OFFENSE',ic:'⭐',sp:3,req:'splitShot',
   ds:'Always fire 8 bullets in all directions.'},
  {id:'bounces1',nm:'RICOCHET I',br:'DEFENSE',ic:'↩️',sp:1,req:null,
   ds:'+10 bounces on top of all level limits.'},
  {id:'bounces2',nm:'RICOCHET II',br:'DEFENSE',ic:'↪️',sp:2,req:'bounces1',
   ds:'+18 more bounces. Near-infinite flight time.'},
  {id:'caliber',nm:'CALIBER+',br:'DEFENSE',ic:'🎯',sp:1,req:'bounces1',
   ds:'Bullet radius +4px. Easier to land shots.'},
  {id:'ghostBullet',nm:'GHOST ROUND',br:'DEFENSE',ic:'👻',sp:3,req:'caliber',
   ds:'Bullet phases through the very first wall it hits.'},
  {id:'gravBullet',nm:'GRAVITY BEND',br:'DEFENSE',ic:'🌀',sp:2,req:'bounces1',
   ds:'Bullet slowly curves downward — new angles!'},
  {id:'homing',nm:'HEAT SEEKER',br:'DEFENSE',ic:'🏹',sp:3,req:'gravBullet',
   ds:'Bullet slightly steers toward nearest enemy.'},
  {id:'coinBoost',nm:'BOUNTY I',br:'UTILITY',ic:'💰',sp:1,req:null,
   ds:'+50% coins per kill.'},
  {id:'coinBoost2',nm:'BOUNTY II',br:'UTILITY',ic:'💎',sp:2,req:'coinBoost',
   ds:'+60% more coins. Stacks with all bonuses.'},
  {id:'xpBoost',nm:'SCHOLAR',br:'UTILITY',ic:'📚',sp:1,req:null,
   ds:'+50% XP per kill. Level up faster.'},
  {id:'freezeExt',nm:'CRYO EXT',br:'UTILITY',ic:'❄️',sp:2,req:'xpBoost',
   ds:'Time Freeze lasts 9s instead of 6s.'},
  {id:'magnetStr',nm:'MAGNET+',br:'UTILITY',ic:'🧲',sp:2,req:'coinBoost',
   ds:'Magnet radius 160px and lasts 5s longer.'},
  {id:'tripleShot',nm:'TRIPLE SHOT',br:'UTILITY',ic:'🔫',sp:3,req:'magnetStr',
   ds:'Fire 3 bullets simultaneously.'},
];

// ── LEVEL BUILDERS ────────────────────────────────────
function E(x,y,type='normal',opts={}){
  const hp=type==='armored'?2:type==='boss'?8:1;
  return{x,y,ox:x,oy:y,type,hp,maxHp:hp,
    vx:opts.vx||0,vy:opts.vy||0,px:opts.px||x,py:opts.py||y,
    range:opts.range||80,teleT:0,dead:false,id:Math.random(),small:false};
}
function W(x,y,w,h){return{x,y,w,h};}
function MW(x,y,w,h,ax,ay,spd,rng){return{x,y,ox:x,oy:y,w,h,ax,ay,spd:spd*.018,rng,t:0};}
function P(ax,ay,bx,by){return{ax,ay,bx,by,ca:0,cb:0,pa:0,pb:0};}
function PUP(x,y,t){return{x,y,type:t,alive:true};}

// ── ALL 20 LEVELS (bounce limits are generous, hand-tested) ──────
// Each level has a generous bl (base bounce limit before upgrades).
// Even at bl=20 most rooms are completable. Levels scale to bl=30.
const LEVELS=[
/* 0  TUTORIAL */ {bl:20,tip:'AIM YOUR CURSOR · CLICK TO FIRE · HIT ALL TARGETS',
  gun:{x:240,y:650},
  en:[E(148,200),E(332,185)],walls:[],mw:[],portals:[],pups:[]},
/* 1  FIRST WALL */ {bl:22,tip:'BOUNCE THE BULLET OFF WALLS TO REACH EVERY TARGET',
  gun:{x:70,y:638},
  en:[E(378,175),E(215,240),E(388,405)],
  walls:[W(148,295,200,11)],mw:[],portals:[],pups:[PUP(240,510,'freeze')]},
/* 2  MOVING WALL */ {bl:22,tip:'THE ORANGE WALL MOVES — WAIT FOR THE GAP',
  gun:{x:420,y:638},
  en:[E(90,170),E(270,215),E(395,365)],walls:[],
  mw:[MW(155,230,11,180,0,1,1.2,110)],portals:[],pups:[]},
/* 3  PORTAL INTRO */ {bl:24,tip:'ORANGE→PURPLE PORTALS TELEPORT YOUR BULLET INSTANTLY',
  gun:{x:70,y:638},
  en:[E(385,170),E(200,235),E(382,412),E(185,458)],
  walls:[W(155,308,185,11)],mw:[],
  portals:[P(75,220,400,390)],pups:[PUP(240,500,'starburst')]},
/* 4  ARMORED */ {bl:22,tip:'GRAY ENEMIES NEED 2 HITS — OR UNLOCK ARMOR PIERCE SKILL',
  gun:{x:240,y:650},
  en:[E(90,170),E(335,185,'armored'),E(158,388),E(392,402,'armored')],
  walls:[W(155,285,172,11),W(298,175,11,148)],mw:[],portals:[],pups:[PUP(240,390,'bomb')]},
/* 5  MOVING ENEMIES */ {bl:24,tip:'BLUE ENEMIES PATROL PATHS — SHOOT WHERE THEY WILL BE',
  gun:{x:70,y:638},
  en:[E(200,170),E(362,170),E(90,318,'moving',{vx:1.1,px:90,range:115}),E(382,415),E(195,458)],
  walls:[W(148,292,205,11)],mw:[],portals:[],pups:[]},
/* 6  DARK ROOM */ {bl:24,dark:true,tip:'DARK ROOM — NO AIM GUIDE. THE FREEZE PUP LIGHTS YOUR PATH.',
  gun:{x:420,y:638},
  en:[E(90,175),E(240,205),E(382,175),E(90,452),E(382,452)],
  walls:[W(158,308,168,11)],mw:[],portals:[],pups:[PUP(240,390,'freeze')]},
/* 7  PORTALS + ARMORED */ {bl:26,tip:'PORTALS REDIRECT BOUNCES — USE THEM TO REACH ARMORED FOES',
  gun:{x:240,y:650},
  en:[E(90,168,'armored'),E(382,168),E(90,415),E(382,415,'armored'),E(240,322)],
  walls:[],mw:[],portals:[P(158,248,328,248)],pups:[]},
/* 8  SPLITTERS */ {bl:26,tip:'SPLITTERS SPAWN 2 MINI-ENEMIES ON DEATH — HIT THEM TOO',
  gun:{x:70,y:638},
  en:[E(382,178),E(152,235,'splitter'),E(352,382,'splitter'),E(90,452)],
  walls:[W(155,308,185,11)],
  mw:[MW(302,150,11,145,0,1,1.3,95)],portals:[],pups:[PUP(240,510,'magnet')]},
/* 9  BOSS 1 */ {bl:26,tip:'⚠ BOSS — 8 HITS TO KILL · POWER-UPS AVAILABLE BELOW',
  gun:{x:240,y:650},
  en:[E(240,225,'boss'),E(102,198),E(382,198),E(102,395),E(382,395)],
  walls:[],mw:[],portals:[],
  pups:[PUP(138,488,'freeze'),PUP(342,488,'bomb')]},
/* 10 TELEPORTER */ {bl:26,tip:'PURPLE TELEPORTERS JUMP EVERY 4s — FIRE WHEN THEY STOP',
  gun:{x:70,y:638},
  en:[E(388,168),E(122,252,'teleporter'),E(368,322,'teleporter'),
      E(202,178),E(102,432),E(382,438)],
  walls:[W(155,292,200,11),W(302,168,11,132)],mw:[],portals:[],pups:[]},
/* 11 DARK + PORTALS */ {bl:26,dark:true,tip:'DARK ROOM WITH PORTALS — USE THE PORTAL TO BRIDGE THE GAP',
  gun:{x:240,y:650},
  en:[E(90,178),E(240,205),E(382,178),E(90,442),E(382,442),E(240,338),E(162,338)],
  walls:[],mw:[],portals:[P(80,292,402,292)],pups:[PUP(240,468,'starburst')]},
/* 12 MIXED */ {bl:26,tip:'MIXED ENEMIES — PLAN THE ORDER OF KILLS CAREFULLY',
  gun:{x:420,y:638},
  en:[E(90,178),E(262,182,'armored'),E(382,188),
      E(90,318,'moving',{vx:1.0,px:90,range:102}),
      E(352,312),E(102,438,'splitter'),E(388,448)],
  walls:[W(155,282,198,11)],
  mw:[MW(232,150,11,168,0,1,1.3,98)],portals:[],pups:[PUP(240,388,'magnet')]},
/* 13 TELEPORTERS */ {bl:28,tip:'3 TELEPORTERS — WAIT FOR ALIGNMENT THEN FIRE',
  gun:{x:70,y:638},
  en:[E(388,172),E(202,192,'teleporter'),E(348,352,'teleporter'),E(122,332,'teleporter'),
      E(90,458),E(262,292,'armored'),E(382,458)],
  walls:[W(155,278,168,11),W(302,168,11,142)],mw:[],portals:[],pups:[PUP(240,500,'freeze')]},
/* 14 PORTALS + MOVING WALLS */ {bl:28,tip:'MOVING ORANGE WALLS AND PORTALS — PRECISION TIMING',
  gun:{x:240,y:650},
  en:[E(90,178),E(382,178),E(90,422),E(382,422),
      E(240,202),E(168,358),E(318,358),E(240,432)],
  walls:[],
  mw:[MW(158,278,178,11,1,0,1.4,92),MW(298,175,11,132,0,1,1.3,82)],
  portals:[P(76,338,406,338)],pups:[PUP(240,348,'bomb')]},
/* 15 DARK NARROW */ {bl:26,dark:true,tip:'DARK · NARROW CORRIDORS · STARBURST PUP ON LEFT',
  gun:{x:70,y:638},
  en:[E(392,178),E(392,322),E(392,458),E(240,178),E(240,458),E(90,312),E(168,312)],
  walls:[W(158,238,11,202),W(308,238,11,202)],mw:[],portals:[],
  pups:[PUP(90,458,'starburst')]},
/* 16 SPLITTER FRENZY */ {bl:28,tip:'SPLITTERS EVERYWHERE — USE EXPLOSIVE SKILL OR MAGNET',
  gun:{x:420,y:638},
  en:[E(96,182,'splitter'),E(248,178,'splitter'),E(382,188,'splitter'),
      E(108,422,'armored'),E(382,428,'armored'),E(240,312),E(158,312),E(332,312)],
  walls:[W(155,288,172,11)],
  mw:[MW(170,155,11,158,0,1,1.4,98)],portals:[],pups:[PUP(240,468,'magnet')]},
/* 17 ALL ENEMIES */ {bl:28,tip:'ALL TYPES PRESENT — USE YOUR FULL ARSENAL',
  gun:{x:240,y:650},
  en:[E(90,178),E(382,178,'armored'),
      E(90,318,'moving',{vx:1.1,px:90,range:112}),
      E(240,232,'teleporter'),E(372,322),
      E(90,448,'splitter'),E(382,448),
      E(240,282,'boss'),E(168,312)],
  walls:[W(155,285,198,11)],
  mw:[MW(298,170,11,142,0,1,1.5,92)],
  portals:[P(80,382,402,252)],
  pups:[PUP(158,468,'freeze'),PUP(328,468,'bomb')]},
/* 18 DARK EVERYTHING */ {bl:28,dark:true,tip:'DARK + ALL MECHANICS — TRUST YOUR SKILLS',
  gun:{x:70,y:638},
  en:[E(388,178),E(240,198,'armored'),
      E(382,318,'moving',{vx:1.0,px:322,range:102}),
      E(168,282,'teleporter'),E(352,198,'splitter'),
      E(90,428,'armored'),E(382,442,'splitter'),
      E(240,438),E(168,402),E(318,402)],
  walls:[W(155,255,172,11)],
  mw:[MW(308,178,11,138,0,1,1.5,92)],
  portals:[P(76,332,406,332)],
  pups:[PUP(240,348,'magnet'),PUP(240,468,'starburst')]},
/* 19 FINAL BOSS */ {bl:30,tip:'⚠ FINAL BOSS — THE BULLET GOD AWAKENS · USE EVERYTHING',
  gun:{x:240,y:652},
  en:[E(240,202,'boss'),E(102,178),E(382,178),
      E(102,372,'armored'),E(382,372,'armored'),
      E(168,442,'splitter'),E(318,442,'splitter'),
      E(240,302,'teleporter')],
  walls:[],mw:[],portals:[P(80,278,402,278)],
  pups:[PUP(132,498,'freeze'),PUP(240,498,'bomb'),PUP(352,498,'starburst')]},

/* 20 ASCENSION I — Double portal chain */ {bl:28,tip:'TWO PORTAL PAIRS — CHAIN YOUR BULLET THROUGH BOTH',
  gun:{x:70,y:638},
  en:[E(390,158),E(390,280),E(390,420),E(160,158),E(160,280),E(160,420)],
  walls:[W(210,130,60,11),W(210,430,60,11)],mw:[],
  portals:[P(80,230,402,360),P(80,360,402,230)],
  pups:[PUP(240,490,'freeze')]},

/* 21 ARMORED FORTRESS */ {bl:28,tip:'ALL ARMORED — UNLOCK ARMOR PIERCE OR BOUNCE TWICE ON EACH',
  gun:{x:240,y:650},
  en:[E(102,162,'armored'),E(240,162,'armored'),E(382,162,'armored'),
      E(102,310,'armored'),E(382,310,'armored'),
      E(102,458,'armored'),E(240,458,'armored'),E(382,458,'armored')],
  walls:[W(168,240,50,11),W(268,240,50,11),W(168,375,50,11),W(268,375,11,50)],
  mw:[],portals:[],pups:[PUP(240,315,'bomb')]},

/* 22 TELEPORT MAZE */ {bl:30,tip:'5 TELEPORTERS IN A MAZE — PATIENCE IS YOUR WEAPON',
  gun:{x:420,y:638},
  en:[E(102,162,'teleporter'),E(240,162),E(382,162,'teleporter'),
      E(102,310,'teleporter'),E(382,310),E(102,458),E(240,458,'teleporter'),E(382,458,'teleporter')],
  walls:[W(168,238,120,11),W(168,238,11,120),W(298,358,11,110)],
  mw:[],portals:[P(200,130,200,490)],
  pups:[PUP(240,315,'freeze'),PUP(240,380,'starburst')]},

/* 23 SPLITTER CASCADE */ {bl:28,tip:'CHAIN KILLS — EACH SPLITTER FEEDS THE NEXT CHAIN',
  gun:{x:70,y:638},
  en:[E(382,152,'splitter'),E(382,290,'splitter'),E(382,428,'splitter'),
      E(240,152,'splitter'),E(240,428,'splitter'),
      E(102,220,'armored'),E(102,368,'armored')],
  walls:[W(168,218,11,250)],
  mw:[MW(300,218,11,200,0,1,1.2,95)],portals:[],
  pups:[PUP(240,315,'magnet'),PUP(340,490,'bomb')]},

/* 24 DARK BOSS */ {bl:28,dark:true,tip:'⚠ DARK ROOM BOSS — USE FREEZE TO ILLUMINATE',
  gun:{x:240,y:650},
  en:[E(240,218,'boss'),E(102,162),E(382,162),E(102,420),E(382,420),E(240,162)],
  walls:[],mw:[MW(168,280,120,11,1,0,1.3,80)],
  portals:[P(80,342,402,342)],
  pups:[PUP(102,498,'freeze'),PUP(240,498,'bomb'),PUP(382,498,'freeze')]},

/* 25 THE GAUNTLET */ {bl:30,tip:'EVERY WALL MOVES — TIME YOUR ANGLES CAREFULLY',
  gun:{x:420,y:638},
  en:[E(102,162),E(240,162),E(382,162),E(102,310),E(382,310),E(102,458),E(240,458),E(382,458)],
  walls:[],
  mw:[MW(168,230,11,180,0,1,1.1,100),MW(298,230,11,180,0,1,1.4,100),
      MW(168,230,140,11,1,0,1.2,90),MW(168,378,140,11,1,0,1.5,90)],
  portals:[],pups:[PUP(240,315,'freeze'),PUP(240,380,'magnet')]},

/* 26 MIRROR MADNESS */ {bl:30,tip:'PORTALS ON ALL SIDES — YOUR BULLET TRAVELS THE WHOLE ROOM',
  gun:{x:70,y:638},
  en:[E(240,178),E(152,268,'armored'),E(328,268,'armored'),
      E(102,380,'moving',{vx:1.1,px:102,range:100}),E(382,380,'moving',{vx:-1.1,px:382,range:100}),
      E(240,458,'teleporter'),E(240,318,'splitter')],
  walls:[W(180,230,10,200),W(298,230,10,200)],
  mw:[],
  portals:[P(80,178,402,540),P(80,540,402,178)],
  pups:[PUP(240,455,'starburst')]},

/* 27 BOSS RUSH */ {bl:30,tip:'⚠ TWO BOSSES · PLUS MINIONS · FINAL CHALLENGE BEGINS',
  gun:{x:240,y:650},
  en:[E(130,220,'boss'),E(352,220,'boss'),
      E(102,158),E(382,158),E(240,158),
      E(102,420,'armored'),E(382,420,'armored'),
      E(168,350,'splitter'),E(318,350,'splitter')],
  walls:[W(210,278,60,11)],mw:[],
  portals:[P(80,340,402,340)],
  pups:[PUP(102,498,'freeze'),PUP(240,498,'bomb'),PUP(382,498,'starburst')]},

/* 28 CHAOS DARK */ {bl:30,dark:true,tip:'DARK · TWO BOSSES · MOVING WALLS · YOU ARE READY',
  gun:{x:70,y:638},
  en:[E(168,200,'boss'),E(318,200,'boss'),
      E(102,162),E(382,162),E(240,310,'teleporter'),
      E(102,420,'moving',{vx:1.0,px:102,range:100}),E(382,420,'splitter'),
      E(240,420,'armored')],
  walls:[],
  mw:[MW(168,268,150,11,1,0,1.3,88),MW(168,380,11,130,0,1,1.5,90)],
  portals:[P(80,310,402,310)],
  pups:[PUP(168,498,'freeze'),PUP(240,498,'bomb'),PUP(318,498,'magnet')]},

/* 29 THE ASCENSION — Ultimate Final */ {bl:30,tip:'⚠ THE ASCENSION — ULTIMATE CHALLENGE · BECOME THE BULLET GOD',
  gun:{x:240,y:652},
  en:[E(240,185,'boss'),E(102,158),E(382,158),E(240,158),
      E(102,275,'armored'),E(382,275,'armored'),
      E(102,390,'moving',{vx:1.1,px:102,range:100}),E(382,390,'moving',{vx:-1.1,px:382,range:100}),
      E(168,390,'splitter'),E(318,390,'splitter'),
      E(240,308,'teleporter')],
  walls:[W(178,238,50,11),W(258,238,50,11)],
  mw:[MW(168,308,150,11,1,0,1.4,90)],
  portals:[P(80,258,402,430),P(80,430,402,258)],
  pups:[PUP(102,500,'freeze'),PUP(240,500,'bomb'),PUP(382,500,'starburst'),PUP(168,500,'magnet')]},
];

// ── PATH COMPUTATION ──────────────────────────────────
function computePath(gx,gy,angle,walls,mwalls,portals,maxB,type,frozen){
  // frozen param: pass true only for live bullet mid-freeze. Default false.
  const isFrozen=!!frozen;
  const BR=getBR();
  const pts=[{x:gx,y:gy,b:false}];
  let x=gx,y=gy,dx=Math.cos(angle)*STEP,dy=Math.sin(angle)*STEP;
  let bounces=0,ghUsed=false,gravDy=0;
  // Portal cooldown (separate copy for path computation)
  const pcool=portals.map(()=>({ca:0,cb:0}));

  for(let s=0;s<MAX_STEPS;s++){
    if(bounces>maxB)break;
    // Gravity
    if(type==='gravity'){gravDy+=.0028*STEP;const base=Math.sin(angle)*STEP;dy=base+gravDy;}
    // Homing
    if(type==='homing'){
      const ae=lvEn.filter(e=>!e.dead);
      if(ae.length){
        const t2=ae[0];
        const ta=Math.atan2(t2.y-y,t2.x-x);
        const da=((ta-Math.atan2(dy,dx))+3*Math.PI)%(2*Math.PI)-Math.PI;
        const rot=Math.min(.038,Math.abs(da))*Math.sign(da);
        const ca2=Math.atan2(dy,dx)+rot;dx=Math.cos(ca2)*STEP;dy=Math.sin(ca2)*STEP;
      }
    }
    let nx=x+dx,ny=y+dy,bounced=false;
    // ── PORTALS ──
    for(let pi=0;pi<portals.length;pi++){
      const p=portals[pi],pc=pcool[pi];
      if(pc.ca>0){pc.ca--;}
      if(pc.cb>0){pc.cb--;}
      if(pc.ca<=0&&Math.hypot(nx-p.ax,ny-p.ay)<PORT_R+BR){
        nx=p.bx;ny=p.by;pc.ca=80;pc.cb=80;
        break;
      }
      if(pc.cb<=0&&Math.hypot(nx-p.bx,ny-p.by)<PORT_R+BR){
        nx=p.ax;ny=p.ay;pc.ca=80;pc.cb=80;
        break;
      }
    }
    // ── ROOM BOUNDS ──
    if(nx-BR<ROOM.x){nx=ROOM.x+BR+.5;dx=Math.abs(dx);if(!isFrozen)bounces++;bounced=true;}
    else if(nx+BR>ROOM.x+ROOM.w){nx=ROOM.x+ROOM.w-BR-.5;dx=-Math.abs(dx);if(!isFrozen)bounces++;bounced=true;}
    if(ny-BR<ROOM.y){ny=ROOM.y+BR+.5;dy=Math.abs(dy);if(!isFrozen)bounces++;bounced=true;if(type==='gravity')gravDy=Math.abs(gravDy)*.65;}
    else if(ny+BR>ROOM.y+ROOM.h){ny=ROOM.y+ROOM.h-BR-.5;dy=-Math.abs(dy);if(!isFrozen)bounces++;bounced=true;if(type==='gravity')gravDy=-Math.abs(gravDy)*.65;}
    // ── WALLS ──
    const allW=[...walls,...mwalls.map(w=>({x:w.x,y:w.y,w:w.w,h:w.h}))];
    for(const w of allW){
      const ex=w.x-BR,ey=w.y-BR,ew=w.w+BR*2,eh=w.h+BR*2;
      if(nx>ex&&nx<ex+ew&&ny>ey&&ny<ey+eh){
        if(!ghUsed&&hs('ghostBullet')){ghUsed=true;break;}
        const inX=x>ex&&x<ex+ew,inY=y>ey&&y<ey+eh;
        if(!inY){dy=-dy;ny=y+dy*2;}
        else if(!inX){dx=-dx;nx=x+dx*2;}
        else{dx=-dx;dy=-dy;nx=x+dx;ny=y+dy;}
        if(!isFrozen)bounces++;bounced=true;break;
      }
    }
    x=nx;y=ny;
    if(s%2===0||bounced)pts.push({x,y,b:bounced});
  }
  return pts;
}

function getHits(path){
  const BR=getBR(),hit=new Set();
  for(const pt2 of path) for(let i=0;i<lvEn.length;i++){
    if(hit.has(i)||lvEn[i].dead)continue;
    const er=EN_R+(lvEn[i].type==='boss'?22:lvEn[i].small?-5:0);
    if(Math.hypot(pt2.x-lvEn[i].x,pt2.y-lvEn[i].y)<er+BR)hit.add(i);
  }
  return[...hit];
}

// ── LEVEL LOAD ────────────────────────────────────────
function loadLevel(idx){
  if(idx>=LEVELS.length){showComplete();return;}
  const lv=LEVELS[idx];lvIdx=idx;
  lvGun={...lv.gun};
  lvEn=lv.en.map(e=>({...e,dead:false,hp:e.maxHp,teleT:0,_vx:e.vx||0,_vy:e.vy||0}));
  lvWalls=lv.walls.map(w=>({...w}));
  lvMW=lv.mw.map(w=>({...w,t:0}));
  lvPortals=lv.portals.map(p=>({...p,ca:0,cb:0}));
  lvPups=lv.pups.map(p=>({...p,alive:true}));
  lvBL=lv.bl;lvDark=lv.dark||false;
  aimAngle=null;traj=[];trajHits=[];
  parts=[];floats=[];
  shake=0;flashA=0;slowMo=false;slowMoT=0;bounceFrozen=false;
  magnet=false;magnetT=0;
  combo=0;comboT=0;
  killsLv=0;coinsLv=0;xpLv=0;shotsLv=0;
  fBuls=[];fDone=false;activePup=null;
  gs='aim';save();syncUI();hideAll();
}

// ── KILL / DAMAGE ─────────────────────────────────────
function killEnemy(idx){
  const e=lvEn[idx];if(!e||e.dead)return;
  e.dead=true;
  const earned=getCPK(),xpe=getXPK();
  coinsLv+=earned;coins+=earned;xpLv+=xpe;xp+=xpe;totalKills++;
  combo++;comboT=.55;
  if(e.type==='boss')tryAch('boss_kill');
  checkAchs();
  SND.kill();shake=Math.max(shake,5+Math.min(combo*2,16));
  burst(e.x,e.y,'#ff5500',22,6);burst(e.x,e.y,'#ff9900',10,3);
  for(let i=0;i<10;i++){const a=i/10*Math.PI*2;
  pt(e.x,e.y,Math.cos(a)*3.5,Math.sin(a)*3.5-1.5,'#ffd700',.9,3,.12);}
  fl(e.x,e.y-30,`+${earned}`,'#ffd700',12);
  if(combo>=2){
    const lb=['','','DOUBLE!','TRIPLE!','QUAD!!','PENTA!!','HEXA!!!','ULTRA!!!!'][Math.min(combo,7)]||`×${combo}!!!`;
    const cl=combo>=5?'#ff44ff':combo>=3?'#ff9900':'#ffff55';
    fl(240,342,lb,cl,14+combo*2);SND.combo(combo);shake=Math.max(shake,combo*4);
  }
  // Explosive chain
  if(hs('explosive'))lvEn.forEach((ne,ni)=>{
    if(ne.dead||ni===idx)return;
    if(Math.hypot(ne.x-e.x,ne.y-e.y)<80)setTimeout(()=>killEnemy(ni),115+Math.random()*75);
  });
  // Splitter spawns babies
  if(e.type==='splitter'&&!e.splitDone){
    e.splitDone=true;
    [-1,1].forEach(sign=>{
      const bx=e.x+sign*30,by=e.y;
      const baby={x:bx,y:by,ox:bx,oy:by,type:'normal',hp:1,maxHp:1,dead:false,
        _vx:sign*.9,_vy:0,vx:sign*.9,vy:0,px:bx,py:by,range:65,teleT:0,id:Math.random(),small:true,splitDone:false};
      lvEn.push(baby);burst(bx,by,'#ffff44',8,3);
    });
    fl(e.x,e.y-42,'SPLIT!','#ffff44',12);
  }
  checkWin();
  // XP level up
  while(xp>=plvl*XP_PER_LV&&plvl<MAX_PLV){
    xp-=plvl*XP_PER_LV;plvl++;sp++;
    SND.lvlup();fl(BW/2,252,`▲ LEVEL UP! LV${plvl}`,'#3dffa0',17);
    burst(240,360,'#3dffa0',28,8);shake=14;
  }
  save();
}

function damageBoss(idx){
  const e=lvEn[idx];if(!e||e.dead)return;
  e.hp--;shake=Math.max(shake,8);burst(e.x,e.y,'#ff8800',12,4);
  fl(e.x,e.y-32,`-1 HP`,'#ff8800',11);
  if(e.hp<=0)killEnemy(idx);else SND.boss();
}

function checkWin(){
  if(lvEn.filter(e=>!e.dead).length>0)return;
  fDone=true;fBuls.forEach(b=>b.done=true);
  slowMo=true;slowMoT=2;flashA=.8;flashCol='255,215,0';
  burst(240,382,'#ffd700',40,10);burst(240,382,'#ff9900',25,7);
  SND.win();fl(240,362,'★ DIVINE ★','#ffd700',28);
  coinsLv+=PERF_BONUS;coins+=PERF_BONUS;
  lvStars=shotsLv===1?3:shotsLv===2?2:1;
  if(_dailyPending){
    _dailyPending=false;const today=new Date().toDateString();
    dailyDone=true;dailyDate=today;coins+=DAILY_BONUS;sp+=3;hints+=1;
    tryAch('daily_done');
    fl(240,300,'DAILY COMPLETE!','#ffaa00',17);fl(240,322,`+${DAILY_BONUS}💰 +3SP +💡`,'#3dffa0',13);
  }
  save();setTimeout(()=>{if(gs==='firing'){gs='win';showWin();}},2000);
}

// ── FIRE ──────────────────────────────────────────────
function fireBullet(){
  if(gs!=='aim'||aimAngle===null)return;
  SND.fire();shotsLv++;totalShots++;
  burst(lvGun.x,lvGun.y,'#ffd700',10,3);
  const bt=getBT(),cnt=getSC(),maxB=getMaxB(lvBL);
  fBuls=[];
  const makeB=(ang)=>{
    const p=computePath(lvGun.x,lvGun.y,ang,lvWalls,lvMW,lvPortals,maxB,bt,bounceFrozen);
    return{path:p,idx:0,trail:[],done:false,split:false,bounceCount:0};
  };
  if(cnt===8){for(let i=0;i<8;i++)fBuls.push(makeB(aimAngle+(i/8)*Math.PI*2));}
  else if(cnt===3){[-1,0,1].forEach(i=>fBuls.push(makeB(aimAngle+i*.09)));}
  else fBuls.push(makeB(aimAngle));
  fDone=false;gs='firing';
}

// ── UPDATE FIRING ─────────────────────────────────────
function updateFiring(dt){
  if(fDone)return;
  const spd=slowMo?3:17;
  let allDone=true;
  const BR=getBR();

  fBuls.forEach(b=>{
    if(b.done)return;
    const prev=b.idx;
    b.idx=Math.min(b.idx+spd,b.path.length-1);
    if(b.idx<b.path.length-1)allDone=false;
    else b.done=true;
    const pos=b.path[b.idx];
    b.trail=[...b.trail.slice(-26),{...pos}];

    // Bounce sound
    for(let si=prev+1;si<=b.idx;si++){
      if(b.path[si]?.b){const n=Date.now();if(n-lastBounceT>62){SND.bounce();shake=Math.max(shake,2);lastBounceT=n;}break;}
    }

    // Split Shot
    if(hs('splitShot')&&!b.split){
      for(let si=prev+1;si<=b.idx;si++){
        if(b.path[si]?.b){
          b.split=true;
          const maxB=getMaxB(lvBL),bt=getBT();
          const ca=Math.atan2(pos.y-b.path[Math.max(0,b.idx-3)].y,pos.x-b.path[Math.max(0,b.idx-3)].x);
          [ca+.45,ca-.45].forEach(na=>{
            const p=computePath(pos.x,pos.y,na,lvWalls,lvMW,lvPortals,Math.floor(maxB/2),bt,bounceFrozen);
            fBuls.push({path:p,idx:0,trail:[],done:false,split:true,bounceCount:0});
          });
          fl(pos.x,pos.y,'SPLIT!','#ffd700',11);break;
        }
      }
    }

    // Power-ups
    lvPups.forEach(pu=>{
      if(!pu.alive)return;
      if(Math.hypot(pos.x-pu.x,pos.y-pu.y)<BR+PUP_R){
        pu.alive=false;SND.pup();
        burst(pu.x,pu.y,'#3dffa0',14,4);
        fl(pu.x,pu.y-32,pu.type.toUpperCase()+'!','#3dffa0',13);
        if(pu.type==='freeze'){
          slowMo=true;slowMoT=getFreezeDur();bounceFrozen=true;
          SND.freeze();fl(BW/2,302,'⏸ TIME FROZEN','#88ddff',16);
          flashA=.3;flashCol='50,150,255';
        }
        if(pu.type==='magnet'){magnet=true;magnetT=5+(hs('magnetStr')?5:0);}
        if(pu.type==='bomb'){activePup='bomb';}
        if(pu.type==='starburst'){
          // Immediately fire 8 more from current pos
          const maxB=getMaxB(lvBL),bt=getBT();
          for(let i=0;i<8;i++){
            const a=(i/8)*Math.PI*2;
            const p=computePath(pos.x,pos.y,a,lvWalls,lvMW,lvPortals,maxB,bt,bounceFrozen);
            fBuls.push({path:p,idx:0,trail:[],done:false,split:true,bounceCount:0});
          }
          fl(pos.x,pos.y,'⭐ STARBURST!','#ffdd00',15);burst(pos.x,pos.y,'#ffdd00',24,7);
        }
      }
    });

    // Magnet pull enemies toward center
    if(magnet)lvEn.forEach(e=>{
      if(e.dead)return;
      const d=Math.hypot(240-e.x,382-e.y),mr=getMagR();
      if(d<mr&&d>5){const a=Math.atan2(382-e.y,240-e.x);e.x+=Math.cos(a)*2;e.y+=Math.sin(a)*2;}
    });

    // Portal transit (live)
    lvPortals.forEach(p=>{
      if(p.ca>0)p.ca--;if(p.cb>0)p.cb--;
      if(p.ca<=0&&Math.hypot(pos.x-p.ax,pos.y-p.ay)<PORT_R+BR){
        b.trail=[];// clear trail on portal
        SND.portal();burst(pos.x,pos.y,'#cc44ff',8,3);
        p.ca=80;p.cb=80;
      }
      if(p.cb<=0&&Math.hypot(pos.x-p.bx,pos.y-p.by)<PORT_R+BR){
        b.trail=[];
        SND.portal();burst(pos.x,pos.y,'#ff8800',8,3);
        p.ca=80;p.cb=80;
      }
    });

    // Enemy hit
    lvEn.forEach((e,i)=>{
      if(e.dead)return;
      const er=EN_R+(e.type==='boss'?22:e.small?-5:0);
      if(Math.hypot(pos.x-e.x,pos.y-e.y)<er+BR){
        if(e.type==='boss'){damageBoss(i);}
        else if(e.type==='armored'&&!hs('armorPierce')){
          e.hp--;burst(e.x,e.y,'#8899bb',8,3);SND.bounce();shake=4;
          fl(e.x,e.y-24,'ARMOR!','#8899bb',10);
          if(e.hp<=0){e.type='normal';e.hp=1;fl(e.x,e.y-32,'SHIELD BROKEN!','#ff8800',11);}
        } else if(activePup==='bomb'){
          burst(e.x,e.y,'#ff4400',30,8);burst(e.x,e.y,'#ff9900',20,5);
          fl(e.x,e.y-38,'💥 BOOM!','#ff4400',16);
          lvEn.forEach((_,ni)=>{if(!lvEn[ni].dead&&Math.hypot(lvEn[ni].x-e.x,lvEn[ni].y-e.y)<85)killEnemy(ni);});
          activePup=null;
        } else killEnemy(i);
      }
    });
  });

  if(allDone&&!fDone){
    fDone=true;
    const alive=lvEn.filter(e=>!e.dead).length;
    if(alive>0){
      setTimeout(()=>{
        SND.lose();shake=10;fl(240,362,'MORTAL...','#ff3355',22);
        setTimeout(()=>{if(gs==='firing'){gs='lose';showLose();}},700);
      },380);
    }
  }
}

// ── MAIN UPDATE ───────────────────────────────────────
function update(dt){
  updParts(dt);
  if(shake>0){shake*=.75;if(shake<.06)shake=0;}
  if(flashA>0)flashA=Math.max(0,flashA-dt*2.2);
  if(slowMoT>0){slowMoT-=dt;if(slowMoT<=0){slowMo=false;bounceFrozen=false;}}
  if(magnetT>0){magnetT-=dt;if(magnetT<=0)magnet=false;}
  if(comboT>0){comboT-=dt;if(comboT<=0)combo=0;}
  // Moving walls
  lvMW.forEach(w=>{w.t+=w.spd;const p=Math.sin(w.t);w.x=w.ox+w.ax*p*w.rng;w.y=w.oy+w.ay*p*w.rng;});
  // Moving/teleporting enemies
  lvEn.forEach(e=>{
    if(e.dead)return;
    if(e.type==='moving'||e.small){
      const sd2=slowMo?.2:1;
      e.x+=e._vx*sd2;e.y+=e._vy*sd2;
      if(Math.hypot(e.x-e.px,e.y-e.py)>e.range){e._vx*=-1;e._vy*=-1;}
      e.x=Math.max(ROOM.x+EN_R,Math.min(ROOM.x+ROOM.w-EN_R,e.x));
      e.y=Math.max(ROOM.y+EN_R,Math.min(ROOM.y+ROOM.h-EN_R,e.y));
    }
    if(e.type==='teleporter'){
      e.teleT+=(slowMo?.2:1)*dt;
      if(e.teleT>4){e.teleT=0;
        e.x=ROOM.x+50+Math.random()*(ROOM.w-100);
        e.y=ROOM.y+50+Math.random()*(ROOM.h-100);
        burst(e.x,e.y,'#cc44ff',10,3);SND.portal();
      }
    }
    if(e.type==='boss'){
      const a=Math.atan2(lvGun.y-e.y,lvGun.x-e.x);
      e.x+=Math.cos(a)*.3*(slowMo?.2:1);e.y+=Math.sin(a)*.3*(slowMo?.2:1);
      e.x=Math.max(ROOM.x+50,Math.min(ROOM.x+ROOM.w-50,e.x));
      e.y=Math.max(ROOM.y+50,Math.min(ROOM.y+ROOM.h-140,e.y));
    }
  });
  if(gs==='firing')updateFiring(dt);
}

// ── RENDER ────────────────────────────────────────────
let rafId;
function render(ts){
  const dt=Math.min((ts-lastTs)/1000,.05);lastTs=ts;
  update(dt);
  ctx.clearRect(0,0,BW,BH);
  ctx.save();
  if(shake>0)ctx.translate((Math.random()-.5)*shake*2,(Math.random()-.5)*shake*2);
  if(gs==='aim'||gs==='firing')drawScene();else drawBG();
  ctx.restore();
  if(flashA>0){ctx.fillStyle=`rgba(${flashCol},${flashA.toFixed(3)})`;ctx.fillRect(0,0,BW,BH);}
  rafId=requestAnimationFrame(render);
}

function drawBG(){
  ctx.fillStyle='#02020a';ctx.fillRect(0,0,BW,BH);
  ctx.fillStyle='rgba(255,215,0,.025)';
  for(let gx=24;gx<BW;gx+=26)for(let gy=24;gy<BH;gy+=26){ctx.beginPath();ctx.arc(gx,gy,1,0,Math.PI*2);ctx.fill();}
}

function drawScene(){
  drawBG();
  drawHUD();
  if(lvDark){ctx.fillStyle='rgba(2,2,10,.9)';ctx.fillRect(ROOM.x,ROOM.y,ROOM.w,ROOM.h);}
  // Room border
  ctx.save();ctx.shadowColor='rgba(255,215,0,.45)';ctx.shadowBlur=16;
  ctx.strokeStyle='rgba(255,215,0,.55)';ctx.lineWidth=2;ctx.strokeRect(ROOM.x,ROOM.y,ROOM.w,ROOM.h);ctx.restore();
  ctx.strokeStyle='rgba(255,215,0,.06)';ctx.lineWidth=1;ctx.strokeRect(ROOM.x+4,ROOM.y+4,ROOM.w-8,ROOM.h-8);
  if(!lvDark){ctx.fillStyle='rgba(255,215,0,.018)';
    for(let gx=ROOM.x+22;gx<ROOM.x+ROOM.w;gx+=22)for(let gy=ROOM.y+22;gy<ROOM.y+ROOM.h;gy+=22){ctx.beginPath();ctx.arc(gx,gy,.8,0,Math.PI*2);ctx.fill();}}

  // Level tip
  if(gs==='aim'){
    ctx.fillStyle='rgba(255,215,0,.2)';ctx.font='7.5px Orbitron,monospace';ctx.textAlign='center';
    ctx.fillText(LEVELS[lvIdx]?.tip||'',BW/2,ROOM.y-6);
  }

  // Static walls
  lvWalls.forEach(w=>{
    ctx.save();ctx.shadowColor='#3366ff';ctx.shadowBlur=12;
    ctx.fillStyle='#07082a';ctx.fillRect(w.x,w.y,w.w,w.h);
    ctx.strokeStyle='rgba(60,100,255,.85)';ctx.lineWidth=2;ctx.strokeRect(w.x,w.y,w.w,w.h);ctx.restore();
  });
  // Moving walls
  lvMW.forEach(w=>{
    ctx.save();ctx.shadowColor='var(--orange)';ctx.shadowBlur=14;
    ctx.fillStyle='#1a0800';ctx.fillRect(w.x,w.y,w.w,w.h);
    ctx.strokeStyle='rgba(255,140,0,.9)';ctx.lineWidth=2.5;ctx.strokeRect(w.x,w.y,w.w,w.h);ctx.restore();
    ctx.fillStyle='rgba(255,140,0,.35)';ctx.font='9px monospace';ctx.textAlign='center';
    ctx.fillText(w.ax?'◀▶':'▲▼',w.x+w.w/2,w.y+w.h/2+3.5);
  });

  // ── PORTALS (improved) ──
  const t=Date.now()/1000;
  lvPortals.forEach(p=>{
    [[p.ax,p.ay,'#ff8c00','#ffaa44','IN'],[p.bx,p.by,'#cc44ff','#ee88ff','OUT']].forEach(([px,py,c1,c2,lbl])=>{
      // Spinning ring
      ctx.save();
      ctx.translate(px,py);ctx.rotate(t*2.2);
      ctx.shadowColor=c1;ctx.shadowBlur=22+6*Math.sin(t*3);
      ctx.strokeStyle=c1;ctx.lineWidth=3;
      ctx.beginPath();ctx.arc(0,0,PORT_R,0,Math.PI*2);ctx.stroke();
      // Inner dashes
      ctx.strokeStyle=c2;ctx.lineWidth=1.5;ctx.setLineDash([5,5]);
      ctx.beginPath();ctx.arc(0,0,PORT_R-6,0,Math.PI*2);ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
      // Fill
      const grd=ctx.createRadialGradient(px,py,0,px,py,PORT_R);
      grd.addColorStop(0,c1+'55');grd.addColorStop(1,c1+'08');
      ctx.fillStyle=grd;ctx.beginPath();ctx.arc(px,py,PORT_R,0,Math.PI*2);ctx.fill();
      // Label
      ctx.fillStyle=c2;ctx.font='bold 8px Orbitron,monospace';ctx.textAlign='center';
      ctx.fillText(lbl,px,py-PORT_R-6);
    });
    // Link
    ctx.strokeStyle='rgba(200,100,255,.1)';ctx.setLineDash([4,8]);ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(p.ax,p.ay);ctx.lineTo(p.bx,p.by);ctx.stroke();ctx.setLineDash([]);
  });

  // Power-ups
  const pupCols={freeze:'#88ddff',starburst:'#ffdd00',magnet:'#ff88cc',bomb:'#ff5500'};
  const pupIcons={freeze:'❄',starburst:'⭐',magnet:'🧲',bomb:'💣'};
  lvPups.forEach(pu=>{
    if(!pu.alive)return;
    const c=pupCols[pu.type]||'#fff';
    const pulse=.65+.35*Math.sin(t*3.8);
    ctx.save();ctx.shadowColor=c;ctx.shadowBlur=14*pulse;
    // Outer ring
    ctx.strokeStyle=c;ctx.lineWidth=2;ctx.globalAlpha=.7+.3*pulse;
    ctx.beginPath();ctx.arc(pu.x,pu.y,PUP_R,0,Math.PI*2);ctx.stroke();
    // Fill
    ctx.fillStyle=c+'18';ctx.beginPath();ctx.arc(pu.x,pu.y,PUP_R,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;ctx.restore();
    ctx.font='13px monospace';ctx.textAlign='center';ctx.fillText(pupIcons[pu.type]||'?',pu.x,pu.y+5);
    ctx.fillStyle=c;ctx.font='6.5px Orbitron,monospace';ctx.textAlign='center';
    ctx.fillText(pu.type.toUpperCase(),pu.x,pu.y+PUP_R+11);
  });

  // Trajectory
  if(gs==='aim'&&!lvDark&&traj.length>1){
    ctx.setLineDash([4,7]);
    for(let i=1;i<traj.length;i++){
      const f=i/traj.length,a=Math.max(.018,.38*(1-f));
      ctx.strokeStyle=`rgba(255,215,0,${a})`;ctx.lineWidth=1.5;
      ctx.beginPath();ctx.moveTo(traj[i-1].x,traj[i-1].y);ctx.lineTo(traj[i].x,traj[i].y);ctx.stroke();
    }
    ctx.setLineDash([]);
    const aliveCount=lvEn.filter(e=>!e.dead).length;
    if(trajHits.length>0){
      const allLocked=trajHits.length>=aliveCount;
      ctx.fillStyle=allLocked?'#3dffa0':'rgba(255,215,0,.65)';
      ctx.font='bold 9px Orbitron,monospace';ctx.textAlign='right';
      ctx.fillText(`⚡ ${trajHits.length}/${aliveCount} LOCKED`,ROOM.x+ROOM.w-8,ROOM.y+ROOM.h-8);
    }
  }

  // Particles
  parts.forEach(p=>{const a=Math.max(0,p.life/p.ml);ctx.globalAlpha=a;ctx.fillStyle=p.c;ctx.beginPath();ctx.arc(p.x,p.y,p.sz*a,0,Math.PI*2);ctx.fill();});
  ctx.globalAlpha=1;

  // ── ENEMIES ──
  const enemyCols={
    normal:['#bb1111','#ff4444','#ff2222'],
    armored:['#4477aa','#88bbdd','#3366aa'],
    moving:['#1144bb','#4488ff','#0033bb'],
    teleporter:['#8822cc','#cc66ff','#7711bb'],
    splitter:['#997700','#ffcc00','#886600'],
    boss:['#cc4400','#ff8800','#bb3300'],
  };
  lvEn.forEach((e,i)=>{
    if(e.dead)return;
    const locked=trajHits.includes(i);
    const pulse=.62+.38*Math.sin(t*2.8+i*1.7);
    const [c1,c2,cg]=enemyCols[e.type]||enemyCols.normal;
    const er=EN_R+(e.type==='boss'?22:e.small?-5:0);
    // Glow
    const gg=ctx.createRadialGradient(e.x,e.y,0,e.x,e.y,er*3);
    gg.addColorStop(0,cg+'44');gg.addColorStop(1,'transparent');
    ctx.fillStyle=gg;ctx.beginPath();ctx.arc(e.x,e.y,er*3,0,Math.PI*2);ctx.fill();
    // Locked extra glow
    if(locked){const gl=ctx.createRadialGradient(e.x,e.y,0,e.x,e.y,er*3.5);
    gl.addColorStop(0,'rgba(255,215,0,.22)');gl.addColorStop(1,'transparent');
    ctx.fillStyle=gl;ctx.beginPath();ctx.arc(e.x,e.y,er*3.5,0,Math.PI*2);ctx.fill();}
    // Body
    ctx.save();ctx.shadowColor=locked?'#ffd700':c1;ctx.shadowBlur=locked?26:14;
    ctx.fillStyle=c1;ctx.beginPath();ctx.arc(e.x,e.y,er,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=c2;ctx.beginPath();ctx.arc(e.x,e.y,er*.54,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.62)';ctx.beginPath();ctx.arc(e.x-er*.32,e.y-er*.32,er*.2,0,Math.PI*2);ctx.fill();
    ctx.restore();
    // Armored ring
    if(e.type==='armored'&&e.hp>1){
      ctx.strokeStyle='rgba(136,187,221,.65)';ctx.lineWidth=3;
      ctx.beginPath();ctx.arc(e.x,e.y,er+4,0,Math.PI*2);ctx.stroke();
    }
    // HP bar (boss + armored)
    if(e.type==='boss'||(e.type==='armored'&&e.hp>0)){
      const bw=er*2.2,bh=4,bx=e.x-er*1.1,by=e.y-er-9;
      ctx.fillStyle='#110000';ctx.fillRect(bx,by,bw,bh);
      ctx.fillStyle=e.type==='boss'?'#ff5500':'#4488ff';ctx.fillRect(bx,by,bw*(e.hp/e.maxHp),bh);
      ctx.strokeStyle='rgba(255,255,255,.15)';ctx.lineWidth=1;ctx.strokeRect(bx,by,bw,bh);
    }
    // Teleporter timer ring
    if(e.type==='teleporter'){
      const ang=(e.teleT/4)*Math.PI*2-Math.PI/2;
      ctx.strokeStyle='rgba(204,68,255,.55)';ctx.lineWidth=2.5;
      ctx.beginPath();ctx.arc(e.x,e.y,er+5,-Math.PI/2,-Math.PI/2+ang);ctx.stroke();
    }
    // Moving arrow
    if(e.type==='moving'||e.small){
      ctx.fillStyle='rgba(68,136,255,.5)';ctx.font='9px monospace';ctx.textAlign='center';
      ctx.fillText(e._vx>0?'→':'←',e.x,e.y-er-4);
    }
    if(locked){ctx.fillStyle='#ffd700';ctx.font='bold 11px monospace';ctx.textAlign='center';ctx.fillText('⚡',e.x,e.y-er-2);}
    if(e.type==='boss'){
      ctx.fillStyle='#ff8800';ctx.font='bold 8.5px Orbitron,monospace';ctx.textAlign='center';
      ctx.fillText(`BOSS  ${e.hp}HP`,e.x,e.y+er+15);
    }
  });

  // ── BULLETS ──
  if(gs==='firing'){
    const BR=getBR();
    fBuls.forEach(b=>{
      if(b.done&&b.trail.length===0)return;
      const pos=b.path[b.idx];
      // Trail
      for(let i=1;i<b.trail.length;i++){
        const tf=i/b.trail.length;
        let tc;
        if(prestige===3)tc=`hsla(${(i*18)%360},100%,62%,${tf*.48})`;
        else if(prestige===2)tc=`hsla(${(Date.now()/9+i*14)%360},100%,60%,${tf*.45})`;
        else tc=`rgba(255,215,0,${tf*.45})`;
        ctx.strokeStyle=tc;ctx.lineWidth=tf*6;ctx.lineCap='round';
        ctx.beginPath();ctx.moveTo(b.trail[i-1].x,b.trail[i-1].y);ctx.lineTo(b.trail[i].x,b.trail[i].y);ctx.stroke();
      }
      if(!b.done){
        ctx.save();ctx.shadowColor='#fff';ctx.shadowBlur=24;
        ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(pos.x,pos.y,BR,0,Math.PI*2);ctx.fill();
        ctx.shadowColor='#ffd700';ctx.shadowBlur=40;
        ctx.fillStyle='rgba(255,215,0,.38)';ctx.beginPath();ctx.arc(pos.x,pos.y,BR+5,0,Math.PI*2);ctx.fill();
        ctx.restore();
      }
    });
  }

  // ── GUN ──
  ctx.save();ctx.shadowColor='#ffd700';ctx.shadowBlur=28;
  ctx.fillStyle='#ffd700';ctx.beginPath();ctx.arc(lvGun.x,lvGun.y,GUN_R,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.88)';ctx.beginPath();ctx.arc(lvGun.x,lvGun.y,GUN_R*.42,0,Math.PI*2);ctx.fill();ctx.restore();
  if(aimAngle!==null&&gs==='aim'){
    ctx.save();ctx.shadowColor='#ffd700';ctx.shadowBlur=12;
    ctx.strokeStyle='#ffd700';ctx.lineWidth=3;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(lvGun.x,lvGun.y);ctx.lineTo(lvGun.x+Math.cos(aimAngle)*28,lvGun.y+Math.sin(aimAngle)*28);
    ctx.stroke();ctx.restore();
  }

  // Floaters
  floats.forEach(f=>{
    const a=Math.min(1,f.life/f.ml*2);ctx.globalAlpha=Math.max(0,a);
    ctx.fillStyle=f.c;ctx.font=`bold ${f.sz}px Orbitron,monospace`;ctx.textAlign='center';
    ctx.shadowColor=f.c;ctx.shadowBlur=10;ctx.fillText(f.txt,f.x,f.y);ctx.shadowBlur=0;
  });
  ctx.globalAlpha=1;

  // Slow mo tint
  if(slowMo){ctx.fillStyle='rgba(80,180,255,.04)';ctx.fillRect(ROOM.x,ROOM.y,ROOM.w,ROOM.h);}
  // Active pup badge
  if(activePup){
    const c=pupCols[activePup]||'#fff';
    ctx.fillStyle=c;ctx.font='bold 9px Orbitron,monospace';ctx.textAlign='left';
    ctx.fillText(`READY: ${activePup.toUpperCase()}`,ROOM.x+8,ROOM.y+ROOM.h-8);
  }
  // Dark room — gun halo only
  if(lvDark){
    const rg=ctx.createRadialGradient(lvGun.x,lvGun.y,0,lvGun.x,lvGun.y,100);
    rg.addColorStop(0,'rgba(2,2,10,0)');rg.addColorStop(1,'rgba(2,2,10,.94)');
    ctx.fillStyle=rg;ctx.fillRect(ROOM.x,ROOM.y,ROOM.w,ROOM.h);
  }
}

// ── HUD ───────────────────────────────────────────────
function drawHUD(){
  ctx.fillStyle='rgba(2,2,10,.93)';ctx.fillRect(0,0,BW,ROOM.y-2);

  // ── LEFT: title + level ──
  ctx.fillStyle='#ffd700';ctx.font='bold 11px Orbitron,monospace';ctx.textAlign='left';
  ctx.fillText('ONE BULLET GOD',18,18);
  const isBoss=LEVELS[lvIdx]?.en.some(e=>e.type==='boss');
  ctx.fillStyle=isBoss?'#ff5500':'rgba(255,215,0,.38)';
  ctx.font='7.5px Orbitron,monospace';
  ctx.fillText(`LV ${lvIdx+1} / 20${isBoss?' · ⚠ BOSS':''}`,18,32);

  // ── XP bar ──
  const xpMax=plvl*XP_PER_LV,xpPct=Math.min(1,xp/xpMax);
  ctx.fillStyle='rgba(255,215,0,.07)';ctx.fillRect(18,37,200,3);
  ctx.fillStyle='#ffd700';ctx.fillRect(18,37,200*xpPct,3);
  ctx.fillStyle='rgba(255,215,0,.28)';ctx.font='6.5px Orbitron,monospace';ctx.textAlign='left';
  ctx.fillText(`PLV ${plvl}`,18,48);

  // ── RIGHT: resources ──
  ctx.textAlign='right';
  ctx.fillStyle='#ffd700';ctx.font='bold 13px Orbitron,monospace';ctx.fillText(`💰 ${coins}`,BW-14,20);
  ctx.fillStyle='rgba(204,68,255,.7)';ctx.font='7.5px Orbitron,monospace';ctx.fillText(`⭐ ${sp} SP`,BW-14,34);

  // ── CENTER: targets ──
  const alive=lvEn.filter(e=>!e.dead).length;
  ctx.textAlign='center';
  const tcol=alive===0?'#3dffa0':alive<=2?'#ffaa00':'rgba(255,80,80,.92)';
  ctx.fillStyle=tcol;ctx.font='bold 11px Orbitron,monospace';
  ctx.fillText(`${alive} / ${lvEn.length}  TARGETS`,BW/2,22);

  // ── BOUNCE BAR ──
  const maxB=getMaxB(lvBL);
  const barW=BW-36;
  ctx.fillStyle='rgba(255,255,255,.05)';ctx.fillRect(18,52,barW,4);
  const basePct=Math.min(1,lvBL/maxB);
  ctx.fillStyle='rgba(68,68,200,.55)';ctx.fillRect(18,52,barW*basePct,4);
  const upgPct=1-basePct;
  ctx.fillStyle='rgba(255,215,0,.75)';ctx.fillRect(18+barW*basePct,52,barW*upgPct,4);
  ctx.fillStyle='rgba(255,215,0,.32)';ctx.font='6.5px Orbitron,monospace';ctx.textAlign='right';
  ctx.fillText(`${maxB} BOUNCES${bounceFrozen?' ❄ FROZEN':''}`,BW-16,49);

  // ── COMBAT STATUS ──
  let cy=65;
  if(combo>=2){ctx.fillStyle=combo>=5?'#ff44ff':'#ff9900';ctx.font='bold 8px Orbitron,monospace';ctx.textAlign='left';ctx.fillText(`× ${combo} COMBO`,18,cy);}
  if(slowMo){ctx.fillStyle='#88ddff';ctx.font='8px Orbitron,monospace';ctx.textAlign='center';ctx.fillText(`❄ FROZEN ${slowMoT.toFixed(1)}s`,BW/2,cy);}
  if(magnet){ctx.fillStyle='#ff88cc';ctx.font='8px Orbitron,monospace';ctx.textAlign='center';ctx.fillText(`🧲 MAGNET ${magnetT.toFixed(1)}s`,BW/2,cy+11);}

  // ── LEVEL DOTS ──
  const dot=8;const dotGap=4;const dtotal=LEVELS.length;
  const dW=Math.min(dtotal,15)*(dot+dotGap)-dotGap;const dx0=(BW-dW)/2;
  // Draw two rows if > 15 levels
  for(let i=0;i<dtotal;i++){
    const row=Math.floor(i/15),col=i%15;
    const isBossL=LEVELS[i]?.en.some(e=>e.type==='boss');
    if(i<lvIdx)ctx.fillStyle='rgba(255,215,0,.75)';
    else if(i===lvIdx)ctx.fillStyle='#fff';
    else ctx.fillStyle=isBossL?'rgba(255,80,0,.4)':'rgba(255,255,255,.1)';
    ctx.beginPath();ctx.arc(dx0+col*(dot+dotGap)+dot/2,89+row*13,dot/2,0,Math.PI*2);ctx.fill();
  }

  // ── FIRE HINT ──
  if(gs==='aim'&&aimAngle!==null){
    ctx.fillStyle='rgba(255,215,0,.2)';ctx.font='8px Orbitron,monospace';ctx.textAlign='center';
    ctx.fillText('CLICK OR TAP TO FIRE',BW/2,ROOM.y+ROOM.h+22);
  }
  if(gs==='aim'&&aimAngle===null){
    ctx.fillStyle='rgba(255,215,0,.15)';ctx.font='8px Orbitron,monospace';ctx.textAlign='center';
    ctx.fillText('MOVE MOUSE OVER ARENA TO AIM',BW/2,ROOM.y+ROOM.h+22);
  }
  // Bullet type badge
  const bt2=getBT();
  if(bt2!=='normal'){ctx.fillStyle='rgba(68,136,255,.55)';ctx.font='7px Orbitron,monospace';ctx.textAlign='left';ctx.fillText(bt2.toUpperCase()+' BULLET',18,65);}
  if(lvDark){ctx.fillStyle='rgba(255,50,50,.45)';ctx.font='7px Orbitron,monospace';ctx.textAlign='center';ctx.fillText('⚫ DARK ROOM – NO AIM GUIDE',BW/2,65);}
}

// ── SCREENS ───────────────────────────────────────────
function hideAll(){document.querySelectorAll('.scr').forEach(s=>s.classList.remove('active'));}
function syncUI(){
  const D=id=>document.getElementById(id);
  D('mCoins').textContent=coins;
  D('mPlvl').textContent=plvl;
  D('mPres').textContent=prestige>0?'★'.repeat(prestige)+' P'+prestige:'—';
  D('mStreak').textContent=streak+'🔥';
  const xpMax=plvl*XP_PER_LV;
  D('mXpBar').style.width=(Math.min(1,xp/xpMax)*100)+'%';
  D('mXpTxt').textContent=`${xp} / ${xpMax}`;
  // New resource rows
  if(D('mLives'))D('mLives').textContent=`${lives}/${getMaxLives()}`;
  if(D('mHints'))D('mHints').textContent=hints;
  if(D('mSkips'))D('mSkips').textContent=skips;
  if(D('mIdle'))D('mIdle').textContent=upg.idleMine*8;
  // Lose screen counters
  if(D('hintCount'))D('hintCount').textContent=hints;
  if(D('skipCount'))D('skipCount').textContent=skips;
  if(D('lLives'))D('lLives').textContent=`${lives}/${getMaxLives()}`;
  buildDots('mDots');
  D('btnPrestige').style.display=plvl>=5?'':'none';
  // Lose-screen tip rotates based on fail count
  if(D('loseTip')){
    const tips=[
      `💡 BUY RICOCHET+ IN SHOP FOR +8 MORE BOUNCES`,
      `💡 USE A HINT — IT SHOWS THE OPTIMAL AIM ANGLE`,
      `💡 TIME FREEZE STOPS BOUNCE COUNTING — BUY FREEZE TOKEN`,
      `💡 SKILL TREE: RICOCHET I ADDS +12 BOUNCES FOR FREE`,
      `💡 STUCK? BUY A LEVEL SKIP FROM THE SHOP`,
      `💡 MAGNET PUP PULLS ALL ENEMIES TO CENTER`,
      `💡 ARMOR PIERCE SKILL ONE-SHOTS ARMORED ENEMIES`,
      `💡 DARK ROOMS HAVE A FREEZE PUP — GRAB IT TO SEE BRIEFLY`,
    ];
    D('loseTip').textContent=tips[shotsLv%tips.length];
  }
  checkAchs();
}
function buildDots(id){
  const el=document.getElementById(id);if(!el)return;el.innerHTML='';
  LEVELS.forEach((_,i)=>{
    const d=document.createElement('div');
    const boss=LEVELS[i]?.en.some(e=>e.type==='boss');
    d.className='ld'+(i<lvIdx?' done':i===lvIdx?' curr':'')+(boss?' boss':'');
    el.appendChild(d);
  });
}
function showWin(){
  gs='win';hideAll();
  // Refill lives on win
  lives=Math.min(lives+1,getMaxLives());
  // Record stars
  const prev=lvStarsMap[lvIdx]||0;
  if(lvStars>prev)lvStarsMap[lvIdx]=lvStars;
  if(shotsLv===1)tryAch('one_shot');
  tryAch('first_win');checkAchs();
  const D=id=>document.getElementById(id);
  D('wStars').textContent='★'.repeat(lvStars)+'☆'.repeat(3-lvStars);
  D('wStats').innerHTML=`<div class="sb"><span class="l">KILLS</span><span class="v g">${killsLv}/${lvEn.length}</span></div><div class="sb"><span class="l">SHOTS USED</span><span class="v">${shotsLv}</span></div>`;
  D('wCoins').textContent=coinsLv;D('wXP').textContent=xpLv;
  const xpMax=plvl*XP_PER_LV;
  D('wXpBar').style.width=(Math.min(1,xp/xpMax)*100)+'%';
  D('wXpTxtL').textContent=`LV${plvl} XP`;D('wXpTxtR').textContent=`${xp} / ${xpMax}`;
  const bs=[];
  if(shotsLv===1)bs.push('★ ONE SHOT WONDER');
  if(killsLv===lvEn.length)bs.push(`⚡ PERFECT +${PERF_BONUS}💰`);
  if(combo>=4)bs.push(`🔥 ×${combo} COMBO`);
  D('wBonuses').innerHTML=bs.map(b=>`<span class="btag">${b}</span>`).join('');
  buildDots('wDots');syncUI();save();
  document.getElementById('sWin').classList.add('active');
}
function showLose(){
  gs='lose';hideAll();
  const alive=lvEn.filter(e=>!e.dead).length;
  document.getElementById('lStats').innerHTML=`<div class="sb"><span class="l">KILLED</span><span class="v g">${killsLv}</span></div><div class="sb"><span class="l">SURVIVED</span><span class="v r">${alive}</span></div><div class="sb"><span class="l">SHOTS</span><span class="v">${shotsLv}</span></div>`;
  document.getElementById('lCoins').textContent=coinsLv;
  document.getElementById('lBounce').textContent=getMaxB(lvBL);
  syncUI();save();document.getElementById('sLose').classList.add('active');
}
function showComplete(){
  gs='complete';hideAll();
  document.getElementById('cKills').textContent=totalKills;
  document.getElementById('cCoins').textContent=coins;
  document.getElementById('cPres').textContent='★'.repeat(prestige)||'0';
  document.getElementById('sComplete').classList.add('active');
}
function showMenu(){gs='menu';hideAll();syncUI();document.getElementById('sMenu').classList.add('active');}

// ── ACTIONS ───────────────────────────────────────────
function startGame(){hideAll();loadLevel(lvIdx);}
function nextLevel(){hideAll();loadLevel(lvIdx+1);}
function retry(){hideAll();loadLevel(lvIdx);}
function fullRestart(){lvIdx=0;save();showMenu();}
function closeOverlay(){
  hideAll();
  if(gs==='win')document.getElementById('sWin').classList.add('active');
  else if(gs==='lose')document.getElementById('sLose').classList.add('active');
  else showMenu();
}

// ── ACHIEVEMENTS ───────────────────────────────────────
const ACHS=[
  {id:'first_kill',nm:'FIRST BLOOD',ic:'🩸',ds:'Kill your first enemy.',rw:30},
  {id:'first_win',nm:'BULLET GOD JR.',ic:'⚡',ds:'Clear your first level.',rw:50},
  {id:'double',nm:'DOUBLE TROUBLE',ic:'✌️',ds:'Score a DOUBLE combo.',rw:30},
  {id:'triple',nm:'TRIPLE THREAT',ic:'🔥',ds:'Score a TRIPLE combo.',rw:60},
  {id:'ultra',nm:'ULTRA INSTINCT',ic:'💫',ds:'Score ×5 combo or higher.',rw:150},
  {id:'one_shot',nm:'ONE SHOT WONDER',ic:'🎯',ds:'Clear a level with exactly 1 shot.',rw:120},
  {id:'lv5',nm:'VETERAN',ic:'🎖',ds:'Reach level 5 in the campaign.',rw:60},
  {id:'lv10',nm:'ELITE',ic:'🏅',ds:'Reach level 10 in the campaign.',rw:120},
  {id:'lv20',nm:'GODLIKE',ic:'🌟',ds:'Reach level 20 in the campaign.',rw:200},
  {id:'lv30',nm:'THE ASCENDED',ic:'👑',ds:'Clear all 30 levels.',rw:500},
  {id:'kills100',nm:'MASSACRE',ic:'💀',ds:'Kill 100 total enemies.',rw:80},
  {id:'kills500',nm:'GENOCIDE',ic:'☠️',ds:'Kill 500 total enemies.',rw:250},
  {id:'streak3',nm:'DEDICATED',ic:'🔥',ds:'Play 3 days in a row.',rw:80},
  {id:'streak7',nm:'OBSESSED',ic:'💎',ds:'Play 7 days in a row.',rw:250},
  {id:'prestige1',nm:'REBORN',ic:'★',ds:'Prestige for the first time.',rw:300},
  {id:'shop5',nm:'ARMS DEALER',ic:'🛒',ds:'Buy 5 shop upgrades.',rw:100},
  {id:'boss_kill',nm:'BOSS SLAYER',ic:'⚔️',ds:'Kill your first boss.',rw:100},
  {id:'daily_done',nm:'DAILY WARRIOR',ic:'📅',ds:'Complete a daily challenge.',rw:50},
  {id:'rich',nm:'GOLD HOARDER',ic:'💰',ds:'Accumulate 2000 coins at once.',rw:200},
];
function tryAch(id){
  if(achDone[id])return;
  const a=ACHS.find(x=>x.id===id);if(!a)return;
  achDone[id]=true;coins+=a.rw;
  SND.upgrade&&SND.upgrade();
  fl(240,285,`🏆 ${a.nm}`,'#ff8c00',12);
  fl(240,303,`+${a.rw} COINS`,'#ffd700',10);
  burst(240,340,'#ff8c00',12,4);
  save();
}
function checkAchs(){
  if(totalKills>=1)tryAch('first_kill');
  if(totalKills>=100)tryAch('kills100');
  if(totalKills>=500)tryAch('kills500');
  if(combo>=2)tryAch('double');
  if(combo>=3)tryAch('triple');
  if(combo>=5)tryAch('ultra');
  if(streak>=3)tryAch('streak3');
  if(streak>=7)tryAch('streak7');
  if(prestige>=1)tryAch('prestige1');
  if(shopBuys>=5)tryAch('shop5');
  if(coins>=2000)tryAch('rich');
  const cleared=Object.keys(lvStarsMap).length;
  if(cleared>=5)tryAch('lv5');
  if(cleared>=10)tryAch('lv10');
  if(cleared>=20)tryAch('lv20');
  if(cleared>=30)tryAch('lv30');
}

// ── HINT SYSTEM ────────────────────────────────────────
// Compute angle that hits the most enemies
function computeHintAngle(){
  const maxB=getMaxB(lvBL),bt=getBT();
  let bestAngle=0,bestHits=-1;
  for(let deg=0;deg<360;deg+=3){
    const a=deg*Math.PI/180;
    const path=computePath(lvGun.x,lvGun.y,a,lvWalls,lvMW,lvPortals,maxB,bt,false);
    const n=countPathHits(path);
    if(n>bestHits){bestHits=n;bestAngle=a;}
  }
  return bestAngle;
}
function countPathHits(path){
  const BR=getBR();const h=new Set();
  for(const p of path)for(let i=0;i<lvEn.length;i++){
    if(h.has(i)||lvEn[i].dead)continue;
    const er=EN_R+(lvEn[i].type==='boss'?22:lvEn[i].small?-5:0);
    if(Math.hypot(p.x-lvEn[i].x,p.y-lvEn[i].y)<er+BR)h.add(i);
  }
  return h.size;
}
function useHintAndRetry(){
  if(hints<=0){fl(240,340,'NO HINTS — BUY IN SHOP!','#ff3355',13);return;}
  hints--;save();
  // load level then apply hint angle
  loadLevel(lvIdx);
  setTimeout(()=>{
    const a=computeHintAngle();
    aimAngle=a;
    const maxB=getMaxB(lvBL);
    traj=computePath(lvGun.x,lvGun.y,aimAngle,lvWalls,lvMW,lvPortals,maxB,getBT(),false);
    trajHits=getHits(traj);
    fl(240,320,'💡 HINT ACTIVE — AIM SHOWN','#44aaff',14);
  },120);
}
function skipLevel(){
  if(skips<=0){fl(240,340,'NO SKIPS — BUY IN SHOP!','#ff3355',13);return;}
  skips--;save();
  fl(240,340,'LEVEL SKIPPED ⏭','#ff8c00',14);
  // Mark as 1-star clear
  lvStarsMap[lvIdx]=lvStarsMap[lvIdx]||1;
  hideAll();loadLevel(lvIdx+1);
}

// ── LEVEL SELECT ───────────────────────────────────────
function openLevelSelect(){
  const grid=document.getElementById('lvGrid');grid.innerHTML='';
  const cleared=Object.keys(lvStarsMap).length;
  document.getElementById('lsCleared').textContent=cleared;
  const totalSt=Object.values(lvStarsMap).reduce((a,b)=>a+b,0);
  document.getElementById('lsStars').textContent=totalSt;
  LEVELS.forEach((lv,i)=>{
    const stars=lvStarsMap[i]||0;
    const unlocked=i<=lvIdx;
    const isBoss=lv.en.some(e=>e.type==='boss');
    const d=document.createElement('div');
    d.className='lvc'+(unlocked?'':' lk')+(isBoss?' boss-lv':'');
    d.innerHTML=`<div class="lv-num">${i+1}</div><div class="lv-st">${'★'.repeat(stars)+'☆'.repeat(3-stars)}</div><div class="lv-tg">${isBoss?'BOSS':lv.dark?'DARK':''}</div>`;
    if(unlocked)d.onclick=()=>{hideAll();loadLevel(i);};
    grid.appendChild(d);
  });
  document.getElementById('sLvSel').classList.add('active');
}

// ── ACHIEVEMENTS SCREEN ────────────────────────────────
function openAchievements(){
  const list=document.getElementById('achList');list.innerHTML='';
  let done=0;
  ACHS.forEach(a=>{
    const isDone=!!achDone[a.id];if(isDone)done++;
    const d=document.createElement('div');d.className='ach'+(isDone?' done':'');
    d.innerHTML=`<span style="font-size:16px">${a.ic}</span><div class="ach-info"><div class="ach-nm">${a.nm}</div><div class="ach-ds">${a.ds}</div><div class="ach-rw">${isDone?'✓ CLAIMED':'Reward: +'+a.rw+' 💰'}</div></div>`;
    list.appendChild(d);
  });
  document.getElementById('achCount').textContent=`${done} / ${ACHS.length}`;
  document.getElementById('achCoins').textContent=coins;
  document.getElementById('sAch').classList.add('active');
}
function openShop(){buildShop();document.getElementById('shpCoins').textContent=coins;document.getElementById('sShop').classList.add('active');}
function buildShop(){
  const c=document.getElementById('shopCards');c.innerHTML='';
  // Section header helper
  const sec=(t)=>{const d=document.createElement('div');d.style.cssText='grid-column:1/-1;color:rgba(255,215,0,.35);font-size:7px;letter-spacing:3px;padding:4px 0 2px;border-bottom:1px solid rgba(255,215,0,.07);margin-top:4px;';d.textContent=t;c.appendChild(d);};
  sec('── PERMANENT UPGRADES ──');
  SHOP.filter(d=>d.type==='perm').forEach(def=>{
    const cur=upg[def.id]||0,mx=cur>=def.max;
    const cost=mx?0:def.costs[cur],ok=!mx&&coins>=cost;
    const d=document.createElement('div');d.className='upc'+(mx?' mx':'');
    d.innerHTML=`<div class="up-ic">${def.ic}</div><div class="up-nm">${def.nm}${cur>0?` <span style="color:var(--green);font-size:7px">LV${cur}</span>`:''}</div><div class="up-dsc">${def.ds}</div><div class="up-vl">${def.val(cur)}</div><button class="up-btn${ok?' can':''}"${ok?'':' disabled'} onclick="buyShop('${def.id}')">${mx?'✓ MAX':ok?`BUY 💰${cost}`:`NEED 💰${cost}`}</button>`;
    c.appendChild(d);
  });
  sec('── CONSUMABLES ──');
  SHOP.filter(d=>d.type==='cons').forEach(def=>{
    const cost=def.cost(),ok=coins>=cost;
    const d=document.createElement('div');d.className='upc';d.style.borderColor='rgba(68,170,255,.22)';
    d.innerHTML=`<div class="up-ic">${def.ic}</div><div class="up-nm" style="color:var(--blue)">${def.nm}</div><div class="up-dsc">${def.ds}</div><div class="up-vl">${def.val()}</div><button class="up-btn${ok?' can':''}"${ok?'':' disabled'} onclick="buyConsumable('${def.id}')">${ok?`BUY 💰${cost}`:`NEED 💰${cost}`}</button>`;
    c.appendChild(d);
  });
}
function buyShop(id){
  const def=SHOP.find(d=>d.id===id);if(!def||def.type!=='perm')return;
  const cur=upg[id]||0;if(cur>=def.max)return;
  const cost=def.costs[cur];if(coins<cost)return;
  coins-=cost;upg[id]=(upg[id]||0)+1;shopBuys++;
  // Extra lives upgrade also bumps max
  if(id==='extraLives'){lives=Math.min(lives+2,getMaxLives());}
  SND.upgrade();burst(240,360,'#ffd700',15,4);fl(240,342,'UPGRADED!','#3dffa0',13);
  save();buildShop();document.getElementById('shpCoins').textContent=coins;syncUI();
}
function buyConsumable(id){
  const def=SHOP.find(d=>d.id===id);if(!def||def.type!=='cons')return;
  const cost=def.cost();if(coins<cost)return;
  coins-=cost;shopBuys++;
  if(id==='buyLives'){lives=getMaxLives();fl(240,342,'LIVES REFILLED! ❤️','#3dffa0',13);}
  if(id==='buyHint'){hints++;fl(240,342,'HINT ADDED! 💡','#44aaff',13);}
  if(id==='buySkip'){skips++;fl(240,342,'SKIP ADDED! ⏭️','#ff8c00',13);}
  if(id==='buyFreeze'){activePup='freeze';fl(240,342,'FREEZE READY! ❄️','#88ddff',13);}
  if(id==='buyBomb'){activePup='bomb';fl(240,342,'BOMB READY! 💣','#ff5500',13);}
  if(id==='buyStarburst'){activePup='starburst';fl(240,342,'STARBURST READY! ⭐','#ffdd00',13);}
  SND.upgrade();save();buildShop();document.getElementById('shpCoins').textContent=coins;syncUI();
}

// ── SKILL TREE ────────────────────────────────────────
function openSkillTree(){buildST();document.getElementById('stSP').textContent=sp;document.getElementById('stCoins').textContent=coins;document.getElementById('sSkill').classList.add('active');}
function buildST(){
  const wrap=document.getElementById('stWrap');wrap.innerHTML='';
  ['OFFENSE','DEFENSE','UTILITY'].forEach(br=>{
    const bdiv=document.createElement('div');bdiv.className='branch';
    const brIc={'OFFENSE':'⚔️','DEFENSE':'🛡️','UTILITY':'🔧'}[br];
    bdiv.innerHTML=`<div class="br-hd">${brIc} ${br}</div>`;
    const row=document.createElement('div');row.className='skrow';
    SKILLS.filter(s=>s.br===br).forEach(def=>{
      const on=hs(def.id),reqOk=!def.req||hs(def.req);
      const canBuy=!on&&reqOk&&sp>=def.sp,lk=!on&&!reqOk;
      const card=document.createElement('div');
      card.className='sk'+(on?' on':lk?' lk':'');
      card.innerHTML=`<span class="sk-sp">${on?'✓':def.sp+'SP'}</span><div class="sk-ic">${def.ic}</div><div class="sk-nm">${def.nm}</div><div class="sk-ds">${def.ds}${def.req&&!on?`<br><em style="color:#224">Requires: ${def.req}</em>`:''}</div>`;
      if(canBuy)card.onclick=()=>buySK(def.id);
      row.appendChild(card);
    });
    bdiv.appendChild(row);wrap.appendChild(bdiv);
  });
}
function buySK(id){
  const def=SKILLS.find(d=>d.id===id);if(!def||hs(id)||sp<def.sp)return;
  if(def.req&&!hs(def.req))return;
  sp-=def.sp;skills[id]=true;
  SND.upgrade();burst(240,360,'#cc44ff',18,5);fl(240,342,'SKILL UNLOCKED!','#cc44ff',13);
  save();buildST();document.getElementById('stSP').textContent=sp;document.getElementById('stCoins').textContent=coins;
}

// ── PRESTIGE ──────────────────────────────────────────
function openPrestige(){syncPrestige();document.getElementById('sPrestige').classList.add('active');}
function syncPrestige(){
  document.getElementById('prCoins').textContent=coins;
  document.getElementById('prLvl').textContent=plvl;
  [1,2,3].forEach(t=>{const r=document.getElementById('pR'+t);prestige>=t?r.classList.add('act'):r.classList.remove('act');});
  const btns=document.getElementById('prBtns');btns.innerHTML='';
  if(plvl>=5&&prestige<3){
    const b=document.createElement('button');b.className='btn p';
    b.textContent=`★ PRESTIGE ${prestige+1}  (RESETS SKILLS)`;
    b.onclick=doPrestige;btns.appendChild(b);
  } else if(plvl<5){
    btns.innerHTML='<p style="color:rgba(80,95,180,.7);font-size:8px;letter-spacing:2px;text-align:center">REACH PLAYER LEVEL 5 TO PRESTIGE</p>';
  } else {
    btns.innerHTML='<p style="color:var(--green);font-size:9px;letter-spacing:2px">✓ MAX PRESTIGE REACHED</p>';
  }
}
function doPrestige(){
  if(plvl<5||prestige>=3)return;
  prestige++;plvl=1;xp=0;skills={};sp=0;
  SND.win();burst(240,360,'#cc44ff',40,10);fl(240,340,'PRESTIGE '+prestige,'#cc44ff',22);shake=18;
  save();syncPrestige();syncUI();
}

// ── DAILY ─────────────────────────────────────────────
function openDaily(){
  const today=new Date().toDateString();
  document.getElementById('dlDate').textContent=today.toUpperCase();
  const dc=document.getElementById('dlContent');
  if(dailyDate===today&&dailyDone){
    dc.innerHTML='<div class="daily-done">✓ COMPLETED TODAY<br>COME BACK TOMORROW!</div>';
  } else {
    const seed=today.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    const dlLv=seed%LEVELS.length;
    dc.innerHTML=`<div class="srow" style="margin:10px 0"><div class="sb" style="max-width:200px"><span class="l">TODAY'S LEVEL</span><span class="v">${dlLv+1}</span></div></div><p style="color:rgba(80,100,180,.7);font-size:8px;letter-spacing:2px;text-align:center;line-height:2;margin-bottom:12px">Clear Level ${dlLv+1} to earn<br><span style="color:var(--gold)">+200 💰</span> and <span style="color:var(--purple)">+2 ⭐SP</span></p><div class="brow"><button class="btn o" onclick="startDaily(${dlLv})">▶ PLAY DAILY</button></div>`;
  }
  document.getElementById('sDaily').classList.add('active');
}
let _dailyPending=false;
function startDaily(dlLv){
  hideAll();_dailyPending=true;
  loadLevel(dlLv);
}

// ── INPUT ─────────────────────────────────────────────
function getPos(e){const r=C.getBoundingClientRect();const s=e.touches?e.touches[0]:e;return{x:(s.clientX-r.left)/SX,y:(s.clientY-r.top)/SX};}
function onMove(e){
  if(gs!=='aim')return;
  const{x,y}=getPos(e);
  aimAngle=Math.atan2(y-lvGun.y,x-lvGun.x);
  const maxB=getMaxB(lvBL);
  traj=computePath(lvGun.x,lvGun.y,aimAngle,lvWalls,lvMW,lvPortals,maxB,getBT(),false);
  trajHits=getHits(traj);
}
C.addEventListener('mousemove',onMove);
C.addEventListener('click',e=>{if(gs==='aim'&&aimAngle!==null)fireBullet();});
C.addEventListener('touchmove',e=>{e.preventDefault();onMove(e);},{passive:false});
C.addEventListener('touchend',e=>{e.preventDefault();if(gs==='aim'&&aimAngle!==null)fireBullet();});


// ── SMARTLINK HANDLER (Free Coins reward) ──────────────────────
// Jab user "Watch Ad for Free Coins" click kare
const SMARTLINK_REWARD = 50; // coins reward
const SMARTLINK_COOLDOWN = 120000; // 2 min cooldown (ms)
let _smartlinkLastClick = 0;

function handleSmartlink() {
  const now = Date.now();
  const btn = document.getElementById('smartlinkBtn');
  if (!btn) return;

  if (now - _smartlinkLastClick < SMARTLINK_COOLDOWN) {
    const remaining = Math.ceil((SMARTLINK_COOLDOWN - (now - _smartlinkLastClick)) / 1000);
    fl(BW/2, 340, `COOLDOWN: ${remaining}s`, '#ff6644', 10);
    return;
  }

  _smartlinkLastClick = now;
  // Give reward after short delay (simulate ad view)
  setTimeout(() => {
    coins += SMARTLINK_REWARD;
    save();
    syncUI();
    fl(BW/2, 300, `+${SMARTLINK_REWARD} 💰 FREE COINS!`, '#ffd700', 13);
    burst(BW/2, 300, '#ffd700', 16, 5);
    if (btn) {
      btn.textContent = '✓ COINS ADDED! (2min cooldown)';
      btn.style.opacity = '0.4';
      btn.style.pointerEvents = 'none';
      setTimeout(() => {
        btn.textContent = '🎁 WATCH AD FOR FREE COINS';
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
      }, SMARTLINK_COOLDOWN);
    }
  }, 800);
}

// ── POPUNDER SESSION CONTROL ───────────────────────────────────
// Script auto-handles popunder, we just ensure 1x per session
// No extra code needed — effectivegatecpm handles the frequency cap

// ── BOOT ──────────────────────────────────────────────
load();syncUI();
document.getElementById('sMenu').classList.add('active');
lastTs=performance.now();requestAnimationFrame(render);
document.addEventListener('click',()=>{try{getAC().resume();}catch(e){}},{once:true});
document.addEventListener('touchstart',()=>{try{getAC().resume();}catch(e){}},{once:true});

// ═══════════════════════════════════════════════════════════════
//  PHP SECURE API INTEGRATION
//  - Server-side score submission with CSRF token
//  - Leaderboard fetch
//  - Progress backup to server
// ═══════════════════════════════════════════════════════════════

const API = window.OBG_CONFIG || { csrf:'', sid:'', apiBase:'api/' };

// ── Secure API Call ───────────────────────────────────────────
async function apiPost(endpoint, data) {
  try {
    const res = await fetch(API.apiBase + endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Csrf-Token': API.csrf,
        'X-Session-Id': API.sid
      },
      body: JSON.stringify(data)
    });
    return await res.json();
  } catch(e) {
    console.warn('API error:', e);
    return { error: e.message };
  }
}

async function apiGet(endpoint) {
  try {
    const res = await fetch(API.apiBase + endpoint);
    return await res.json();
  } catch(e) {
    return { error: e.message };
  }
}

// ── Track session start time (for anti-cheat) ─────────────────
const _sessionStart = Date.now();

// ── Submit Score to Leaderboard ────────────────────────────────
async function submitScore(name) {
  const timePlayed = (Date.now() - _sessionStart) / 1000;
  const result = await apiPost('score.php', {
    name: name.toUpperCase().substring(0, 16),
    coins: coins,
    kills: totalKills,
    level: lvIdx,
    time_played: timePlayed
  });
  if (result.ok) {
    fl(BW/2, 300, result.msg || 'SCORE SUBMITTED!', '#3dffa0', 11);
  }
  return result;
}

// ── Load Leaderboard ───────────────────────────────────────────
async function loadLeaderboard() {
  const list = document.getElementById('lbList');
  if (!list) return;
  list.innerHTML = '<div style="color:rgba(80,100,180,.5);font-size:8px;letter-spacing:2px;text-align:center;padding:20px">LOADING...</div>';

  const result = await apiGet('score.php?lb=1');
  if (result.error || !result.data) {
    list.innerHTML = '<div style="color:rgba(255,80,80,.5);font-size:8px;text-align:center;padding:12px">Could not load leaderboard.</div>';
    return;
  }

  list.innerHTML = '';
  const medals = ['🥇','🥈','🥉'];
  result.data.forEach((r, i) => {
    const div = document.createElement('div');
    div.className = 'lb-row';
    div.innerHTML = `<span class="lb-rank">${medals[i] || '#'+(i+1)}</span>
      <span class="lb-name">${r.name}</span>
      <span class="lb-coins">💰${r.coins.toLocaleString()}</span>
      <span class="lb-lv">LV${r.level}</span>`;
    list.appendChild(div);
  });
}

// ── Override openLeaderboard ───────────────────────────────────
function openLeaderboard() {
  loadLeaderboard();
  document.getElementById('sLeader').classList.add('active');
}

// ── Server-side save backup (in addition to localStorage) ──────
const _origSave = save;
let _saveBackupTimer = null;
save = function() {
  _origSave();
  // Debounce server backup (max once per 30s)
  clearTimeout(_saveBackupTimer);
  _saveBackupTimer = setTimeout(async () => {
    const saveData = localStorage.getItem('obg6');
    if (saveData) {
      await apiPost('score.php', { action: 'save', save_data: JSON.parse(saveData) });
    }
  }, 30000);
};

// ── Show "Submit Score" prompt after game complete ─────────────
const _origShowComplete = showComplete;
showComplete = function() {
  _origShowComplete();
  // Add submit button to complete screen
  const cscreen = document.getElementById('sComplete');
  if (cscreen && !cscreen.querySelector('.lb-submit-btn')) {
    const btn = document.createElement('button');
    btn.className = 'btn g lb-submit-btn';
    btn.style.marginTop = '10px';
    btn.textContent = '🏆 SUBMIT SCORE';
    btn.onclick = async () => {
      const name = prompt('Enter your name for the leaderboard (max 16 chars):') || 'UNKNOWN';
      btn.disabled = true;
      btn.textContent = 'SUBMITTING...';
      const r = await submitScore(name);
      btn.textContent = r.ok ? `✓ RANK #${r.rank}` : '✗ FAILED';
    };
    const brow = cscreen.querySelector('.brow');
    if (brow) brow.parentNode.insertBefore(btn, brow);
  }
};

// ── Add Leaderboard button to main menu ────────────────────────
window.addEventListener('load', () => {
  const menuBrow = document.querySelector('#sMenu .brow:last-of-type');
  if (menuBrow) {
    const lb = document.createElement('button');
    lb.className = 'btn g';
    lb.innerHTML = '🏆 LEADERBOARD';
    lb.onclick = openLeaderboard;
    menuBrow.prepend(lb);
  }
});
