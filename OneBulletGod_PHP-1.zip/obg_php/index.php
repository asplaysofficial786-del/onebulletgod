<?php
// ═══════════════════════════════════════════════════════════════
//  ONE BULLET GOD — PHP Secure Wrapper
// ═══════════════════════════════════════════════════════════════
session_start();

// ── Security Headers ──────────────────────────────────────────
header("X-Frame-Options: SAMEORIGIN");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Content-Security-Policy: default-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com https://www.highperformanceformat.com https://pl28869545.effectivegatecpm.com https://pl28869551.effectivegatecpm.com https://www.effectivegatecpm.com; script-src 'self' 'unsafe-inline' https://www.highperformanceformat.com https://pl28869545.effectivegatecpm.com https://pl28869551.effectivegatecpm.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; frame-src *; img-src * data:;");

if (empty($_SESSION['csrf_token']))  $_SESSION['csrf_token']  = bin2hex(random_bytes(32));
if (empty($_SESSION['session_id']))  $_SESSION['session_id']  = bin2hex(random_bytes(16));

$csrf_token = $_SESSION['csrf_token'];
$session_id = $_SESSION['session_id'];
$version    = '7.3';

if (!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0755, true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="71a0ac8e4bf1a22f637cc107ea66018fc1fef8c4" content="71a0ac8e4bf1a22f637cc107ea66018fc1fef8c4" />
<meta name="csrf-token" content="<?= htmlspecialchars($csrf_token) ?>">
<meta name="sid"         content="<?= htmlspecialchars($session_id) ?>">
<title>ONE BULLET GOD</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/game.css?v=<?= $version ?>">
</head>
<body>

<!-- ══════════════════════════════════════════════════════════
  AD 1 — SOCIAL BAR + POPUNDER (same script, 2 in 1)
  Social bar: sticky floating bar at bottom (auto)
  Popunder: fires on first click, 1x per session (auto)
  Revenue: $0.5–3 CPM combined
═══════════════════════════════════════════════════════════ -->
<script src="https://pl28869545.effectivegatecpm.com/49/50/91/4950915f9f4dbb71e4ce70dc3c5d3bbe.js"></script>

<!-- ══════════════════════════════════════════════════════════
  AD 2 — TOP BANNER 728x90
  Revenue: $0.3–1.5 CPM
═══════════════════════════════════════════════════════════ -->
<div class="ad-top">
  <div class="ad-slot-wrap">
    <span class="ad-label">ADVERTISEMENT</span>
    <script>
      atOptions = {
        'key'    : 'a3b109a6db39223b7a2d15d5ad004223',
        'format' : 'iframe',
        'height' : 90,
        'width'  : 728,
        'params' : {}
      };
    </script>
    <script src="https://www.highperformanceformat.com/a3b109a6db39223b7a2d15d5ad004223/invoke.js"></script>
  </div>
</div>

<?php include __DIR__ . '/assets/screens.html'; ?>

<div id="sLeader" class="scr">
 <div class="si">
  <div class="sttl gold">🏆  LEADERBOARD</div>
  <div class="tag">TOP BULLET GODS WORLDWIDE</div>
  <div id="lbList" style="width:100%;max-width:460px;max-height:55vh;overflow-y:auto;margin:10px 0">
    <div style="color:rgba(80,100,180,.5);font-size:8px;letter-spacing:2px;text-align:center;padding:20px">LOADING...</div>
  </div>
  <button class="btn" onclick="closeOverlay()">← BACK</button>
 </div>
</div>

<!-- GAME CANVAS -->
<div id="game-wrap">
  <canvas id="c"></canvas>
</div>

<!-- ══════════════════════════════════════════════════════════
  AD 3 — NATIVE BANNER (below canvas, looks natural)
  Revenue: $1–4 CPM — highest passive revenue
═══════════════════════════════════════════════════════════ -->
<div class="ad-native-wrap">
  <span class="ad-label">SPONSORED</span>
  <script async="async" data-cfasync="false" src="https://pl28869551.effectivegatecpm.com/26902a13d915e46c4e4793a10968b3d2/invoke.js"></script>
  <div id="container-26902a13d915e46c4e4793a10968b3d2"></div>
</div>

<script>
window.OBG_CONFIG = {
  csrf:    '<?= htmlspecialchars($csrf_token) ?>',
  sid:     '<?= htmlspecialchars($session_id) ?>',
  apiBase: 'api/',
  version: '<?= $version ?>'
};
</script>
<script src="assets/game.js?v=<?= $version ?>"></script>
</body>
</html>
