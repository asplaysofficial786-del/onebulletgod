<?php
// ═══════════════════════════════════════════════════════════════
//  ONE BULLET GOD — Secure Score API
//  Endpoints:
//    POST api/score.php          — submit score
//    GET  api/score.php?lb=1     — get leaderboard
//    POST api/score.php?action=save — save game progress (localStorage backup)
// ═══════════════════════════════════════════════════════════════
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// ── Helpers ───────────────────────────────────────────────────
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function loadJson($file) {
    if (!file_exists($file)) return [];
    $d = json_decode(file_get_contents($file), true);
    return is_array($d) ? $d : [];
}

function saveJson($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

// ── Rate Limiter ──────────────────────────────────────────────
function checkRateLimit($ip, $action = 'score') {
    $file  = __DIR__ . '/../data/rate_limit.json';
    $rates = loadJson($file);
    $key   = md5($ip . $action);
    $now   = time();
    $limit = 20;   // max requests
    $window = 60;  // per 60 seconds

    if (!isset($rates[$key])) {
        $rates[$key] = ['count' => 0, 'reset' => $now + $window];
    }
    if ($now > $rates[$key]['reset']) {
        $rates[$key] = ['count' => 0, 'reset' => $now + $window];
    }
    $rates[$key]['count']++;
    saveJson($file, $rates);

    return $rates[$key]['count'] <= $limit;
}

// ── Anti-Cheat Validator ───────────────────────────────────────
function validateScore($data) {
    // Basic sanity checks
    if (!isset($data['coins'], $data['kills'], $data['level'], $data['time_played'])) {
        return [false, 'Missing fields'];
    }

    $coins      = (int)$data['coins'];
    $kills      = (int)$data['kills'];
    $level      = (int)$data['level'];
    $time_played = (float)$data['time_played'];

    // Impossible value checks
    if ($coins < 0 || $coins > 999999)           return [false, 'Invalid coins'];
    if ($kills < 0 || $kills > 10000)            return [false, 'Invalid kills'];
    if ($level < 0 || $level > 30)               return [false, 'Invalid level'];
    if ($time_played < 5)                         return [false, 'Too fast'];

    // Coins per kill ratio check (max ~60 coins/kill with all boosts)
    if ($kills > 0 && ($coins / $kills) > 500)   return [false, 'Suspicious ratio'];

    return [true, 'OK'];
}

// ── CORS (same origin only) ───────────────────────────────────
$origin = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_HOST'] ?? '';
// Uncomment and set your domain:
// if ($origin !== 'https://yourdomain.com') jsonResponse(['error' => 'Forbidden'], 403);

// ── CSRF Check for POST ───────────────────────────────────────
$csrf_ok = true;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $headers = getallheaders();
    $token   = $headers['X-Csrf-Token'] ?? $headers['x-csrf-token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        $csrf_ok = false;
    }
}

$ip     = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$action = $_GET['action'] ?? ($_GET['lb'] ? 'leaderboard' : 'score');

// ── GET Leaderboard ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['lb'])) {
    $file = __DIR__ . '/../data/scores.json';
    $all  = loadJson($file);
    // Sort by coins desc
    usort($all, fn($a, $b) => $b['coins'] - $a['coins']);
    $top = array_slice($all, 0, 20);
    // Sanitize output — never expose session or IP
    $clean = array_map(fn($r) => [
        'name'   => htmlspecialchars($r['name'] ?? 'UNKNOWN'),
        'coins'  => (int)$r['coins'],
        'kills'  => (int)$r['kills'],
        'level'  => (int)$r['level'],
        'date'   => $r['date'] ?? ''
    ], $top);
    jsonResponse(['ok' => true, 'data' => $clean]);
}

// ── POST Score Submit ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!$csrf_ok) {
        jsonResponse(['error' => 'Invalid CSRF token'], 403);
    }

    if (!checkRateLimit($ip, 'score')) {
        jsonResponse(['error' => 'Rate limit exceeded. Try again later.'], 429);
    }

    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) {
        jsonResponse(['error' => 'Invalid JSON'], 400);
    }

    $action = $body['action'] ?? 'score';

    // ── Save game progress (backup) ──
    if ($action === 'save') {
        $save_data = $body['save_data'] ?? null;
        if ($save_data) {
            $sid  = preg_replace('/[^a-f0-9]/', '', $_SESSION['session_id'] ?? '');
            $file = __DIR__ . "/../data/saves/{$sid}.json";
            if (!is_dir(dirname($file))) mkdir(dirname($file), 0755, true);
            // Limit save file size to 64KB
            $encoded = json_encode($save_data);
            if (strlen($encoded) < 65536) {
                file_put_contents($file, $encoded, LOCK_EX);
                jsonResponse(['ok' => true, 'msg' => 'Saved']);
            } else {
                jsonResponse(['error' => 'Save data too large'], 400);
            }
        }
        jsonResponse(['error' => 'No save data'], 400);
    }

    // ── Submit score to leaderboard ──
    [$valid, $msg] = validateScore($body);
    if (!$valid) {
        // Log suspicious attempts
        $log = __DIR__ . '/../data/suspicious.log';
        file_put_contents($log, date('Y-m-d H:i:s') . " IP:{$ip} Reason:{$msg} Data:" . json_encode($body) . "\n", FILE_APPEND | LOCK_EX);
        jsonResponse(['error' => "Validation failed: {$msg}"], 422);
    }

    // Sanitize name
    $name = preg_replace('/[^A-Z0-9 _\-\.★]/i', '', strtoupper(trim($body['name'] ?? 'UNKNOWN')));
    $name = substr($name ?: 'UNKNOWN', 0, 16);

    $entry = [
        'name'   => $name,
        'coins'  => (int)$body['coins'],
        'kills'  => (int)$body['kills'],
        'level'  => (int)$body['level'],
        'date'   => date('Y-m-d'),
        '_ip'    => md5($ip),           // hashed, never exposed in API output
        '_sid'   => md5($_SESSION['session_id'] ?? ''),
    ];

    $file  = __DIR__ . '/../data/scores.json';
    $all   = loadJson($file);

    // One entry per hashed IP (upsert best score)
    $found = false;
    foreach ($all as &$r) {
        if ($r['_ip'] === $entry['_ip']) {
            if ($entry['coins'] > $r['coins']) {
                $r = array_merge($r, $entry);
            }
            $found = true;
            break;
        }
    }
    unset($r);
    if (!$found) $all[] = $entry;

    // Keep only top 100
    usort($all, fn($a, $b) => $b['coins'] - $a['coins']);
    $all = array_slice($all, 0, 100);
    saveJson($file, $all);

    // Find rank
    $rank = 1;
    foreach ($all as $r) {
        if ($r['_ip'] === $entry['_ip']) break;
        $rank++;
    }

    jsonResponse(['ok' => true, 'rank' => $rank, 'msg' => "Rank #{$rank} on leaderboard!"]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
